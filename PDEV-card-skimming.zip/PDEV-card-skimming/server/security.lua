-- ============================================
-- POSEIDON DEVELOPMENT - Security Module
-- Copyright (c) 2025 Poseidon Developments - All Rights Reserved
-- ============================================

local Security = {}

-- Rate limiting
local rateLimits = {} -- {source: {count, resetTime}}

-- Security settings
local SECURITY_CONFIG = {
    MaxCallsPerMinute = 30, -- Maximum callback calls per minute
    RateLimitWindow = 60, -- Rate limit window in seconds
    MaxDistance = 5.0, -- Maximum allowed distance (server-side validation)
    MinDistance = 0.5, -- Minimum distance (too close = exploit)
    MaxAmount = 10000, -- Maximum amount per transaction (prevent overflow)
    MinAmount = 1, -- Minimum amount
}

-- Check rate limit
function Security.CheckRateLimit(source)
    local currentTime = os.time()
    local limit = rateLimits[source]
    
    if limit then
        if currentTime < limit.resetTime then
            if limit.count >= SECURITY_CONFIG.MaxCallsPerMinute then
                if Config.Debug then
                    print(string.format('[CCSkim Security] Rate limit hit for player %s', source))
                end
                return false, 'Rate limit exceeded'
            end
            limit.count = limit.count + 1
        else
            -- Reset
            rateLimits[source] = {
                count = 1,
                resetTime = currentTime + SECURITY_CONFIG.RateLimitWindow
            }
        end
    else
        rateLimits[source] = {
            count = 1,
            resetTime = currentTime + SECURITY_CONFIG.RateLimitWindow
        }
    end
    
    return true, nil
end

-- Validate distance (server-side)
function Security.ValidateDistance(source, targetCoords, maxDistance)
    if not targetCoords or type(targetCoords) ~= 'vector3' then
        return false, 'Invalid coordinates'
    end
    
    local playerPed = GetPlayerPed(source)
    if not playerPed or playerPed == 0 then
        return false, 'Invalid player'
    end
    
    local playerCoords = GetEntityCoords(playerPed)
    if not playerCoords then
        return false, 'Could not get player coordinates'
    end
    
    local distance = #(playerCoords - targetCoords)
    
    if distance < SECURITY_CONFIG.MinDistance then
        if Config.Debug then
            print(string.format('[CCSkim Security] Distance too close: %.2f (possible exploit)', distance))
        end
        return false, 'Distance validation failed'
    end
    
    if distance > maxDistance then
        if Config.Debug then
            print(string.format('[CCSkim Security] Distance too far: %.2f (max: %.2f)', distance, maxDistance))
        end
        return false, 'Too far away'
    end
    
    return true, distance
end

-- Validate amount
function Security.ValidateAmount(amount)
    if not amount or type(amount) ~= 'number' then
        return false, 'Invalid amount type'
    end
    
    if amount < SECURITY_CONFIG.MinAmount then
        return false, 'Amount too low'
    end
    
    if amount > SECURITY_CONFIG.MaxAmount then
        if Config.Debug then
            print(string.format('[CCSkim Security] Amount too high: %d (possible exploit)', amount))
        end
        return false, 'Amount too high'
    end
    
    -- Check for NaN or infinity
    if amount ~= amount or amount == math.huge or amount == -math.huge then
        return false, 'Invalid amount value'
    end
    
    return true, amount
end

-- Validate target type
function Security.ValidateTargetType(targetType)
    if targetType ~= 'player' and targetType ~= 'npc' then
        return false, 'Invalid target type'
    end
    return true, targetType
end

-- Validate player source
function Security.ValidateSource(source)
    if not source or type(source) ~= 'number' then
        return false, 'Invalid source'
    end
    
    if source < 0 or source > 65535 then
        return false, 'Source out of range'
    end
    
    -- Check if player exists
    local playerName = GetPlayerName(source)
    if not playerName then
        return false, 'Player not found'
    end
    
    return true, source
end

-- Sanitize string input
function Security.SanitizeString(str, maxLength)
    if type(str) ~= 'string' then
        return nil
    end
    
    if maxLength and #str > maxLength then
        str = string.sub(str, 1, maxLength)
    end
    
    -- Remove potentially dangerous characters
    str = string.gsub(str, '[%c%z]', '')
    
    return str
end

-- Validate item name
function Security.ValidateItemName(itemName)
    if not itemName or type(itemName) ~= 'string' then
        return false, 'Invalid item name'
    end
    
    -- Check against allowed items
    local allowedItems = {
        [Config.Items.Skimmer] = true,
        [Config.Items.CreditCard] = true,
        [Config.Items.CardReader] = true,
    }
    
    if not allowedItems[itemName] then
        return false, 'Item not allowed'
    end
    
    return true, itemName
end

-- Log security event
function Security.LogEvent(source, event, details)
    if not Config.Debug then return end
    
    local playerName = GetPlayerName(source) or 'Unknown'
    print(string.format('[CCSkim Security] %s - Player: %s (%s) - Details: %s', 
        event, playerName, source, details or 'N/A'))
end

-- Clear rate limit for player
function Security.ClearRateLimit(source)
    if source then
        rateLimits[source] = nil
    else
        rateLimits = {}
    end
end

-- Get security stats
function Security.GetStats()
    local count = 0
    for _ in pairs(rateLimits) do
        count = count + 1
    end
    return { rateLimited = count }
end

return Security

