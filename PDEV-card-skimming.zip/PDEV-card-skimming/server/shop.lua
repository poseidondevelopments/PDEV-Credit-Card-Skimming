-- ============================================
-- POSEIDON DEVELOPMENT - Shop System (Server)
-- Copyright (c) 2025 Poseidon Developments - All Rights Reserved
-- ============================================

local Framework = require 'server.framework'
local Security = require 'server.security'

local function GetPlayer(source)
    local valid, err = Security.ValidateSource(source)
    if not valid then return nil end
    return Framework.GetPlayer(source)
end

local function RemoveMoney(source, moneyType, amount)
    local Player = GetPlayer(source)
    if not Player then return false end
    
    -- Handle black_money as an item
    if moneyType == 'black_money' then
        if exports.ox_inventory then
            -- Check if player has enough black_money items
            local hasItem = exports.ox_inventory:GetItemCount(source, Config.BlackMoney.ItemName)
            if hasItem and hasItem >= amount then
                return exports.ox_inventory:RemoveItem(source, Config.BlackMoney.ItemName, amount)
            end
            return false
        else
            -- For QBCore/QBox, check if black_money exists in items
            local items = Player.PlayerData.items
            for i = 1, #items do
                local item = items[i]
                if item.name == Config.BlackMoney.ItemName and item.amount >= amount then
                    return Player.Functions.RemoveItem(Config.BlackMoney.ItemName, amount)
                end
            end
            -- Fallback to money function (for QBCore money system)
            return Player.Functions.RemoveMoney('black_money', amount)
        end
    end
    
    -- Handle cash and bank normally
    return Player.Functions.RemoveMoney(moneyType, amount)
end

local function AddItem(source, item, amount, metadata)
    amount = amount or 1
    -- Add decay metadata for ox_inventory if enabled
    if Config.ItemDecay.Enabled and exports.ox_inventory and Config.ItemDecay.DecayTimes[item] and Config.ItemDecay.DecayTimes[item] > 0 then
        metadata = metadata or {}
        metadata.decay = os.time() + Config.ItemDecay.DecayTimes[item]
    end
    if exports.ox_inventory then
        return exports.ox_inventory:AddItem(source, item, amount, metadata)
    else
        local Player = GetPlayer(source)
        if not Player then return false end
        return Player.Functions.AddItem(item, amount, false, metadata)
    end
end

Framework.CreateCallback('poseidon:shop:purchase', function(source, cb, shopIndex, itemIndex, quantity, moneyType)
    local rateOk, rateErr = Security.CheckRateLimit(source)
    if not rateOk then Security.LogEvent(source, 'Shop Rate Limit', rateErr); cb(false, 'Rate limit exceeded'); return end
    local valid, err = Security.ValidateSource(source)
    if not valid then Security.LogEvent(source, 'Invalid Source', err); cb(false, 'Security validation failed'); return end
    if not shopIndex or not Config.Shop.Locations[shopIndex] then cb(false, 'Invalid shop'); return end
    if not itemIndex or not Config.Shop.Items[itemIndex] then cb(false, 'Invalid item'); return end
    local itemData = Config.Shop.Items[itemIndex]
    if not quantity or quantity < 1 or quantity > 10 then cb(false, 'Invalid quantity'); return end
    if moneyType ~= 'cash' and moneyType ~= 'bank' and moneyType ~= 'black_money' then cb(false, 'Invalid payment method'); return end
    if moneyType == 'cash' and not Config.Shop.Settings.UseCash then cb(false, 'Cash payments not accepted'); return
    elseif moneyType == 'bank' and not Config.Shop.Settings.UseBank then cb(false, 'Bank payments not accepted'); return
    elseif moneyType == 'black_money' and not Config.Shop.Settings.UseBlackMoney then cb(false, 'Black money payments not accepted'); return end
    if itemData.stock ~= -1 and itemData.stock < quantity then cb(false, 'Not enough stock'); return end
    local totalPrice = itemData.price * quantity
    local amountOk, amountErr = Security.ValidateAmount(totalPrice)
    if not amountOk then Security.LogEvent(source, 'Invalid Amount', amountErr); cb(false, 'Invalid price'); return end
    local moneyRemoved = RemoveMoney(source, moneyType, totalPrice)
    if not moneyRemoved then cb(false, 'Insufficient funds'); return end
    local itemAdded = AddItem(source, itemData.item, quantity)
    if not itemAdded then
        local Player = GetPlayer(source)
        if Player then Player.Functions.AddMoney(moneyType, totalPrice) end
        cb(false, 'Failed to add item')
        return
    end
    if itemData.stock ~= -1 then Config.Shop.Items[itemIndex].stock = itemData.stock - quantity end
    local Player = GetPlayer(source)
    if Player and Config.Debug then
        local name = Framework.GetPlayerDataField(Player, 'name')
        local citizenid = Framework.GetPlayerDataField(Player, 'citizenid')
        print(string.format('[POSEIDON SHOP] Player %s (%s) purchased %dx %s for $%d', name or 'Unknown', citizenid or 'Unknown', quantity, itemData.label, totalPrice))
    end
    cb(true, 'Purchase successful')
end)
