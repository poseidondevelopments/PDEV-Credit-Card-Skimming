-- ============================================
-- POSEIDON DEVELOPMENT - Framework Detection
-- Copyright (c) 2025 Poseidon Developments - All Rights Reserved
-- ============================================

local Framework = {}

local frameworkType = nil
local frameworkObject = nil

-- Detect framework
function Framework.Detect()
    if frameworkType then
        return frameworkType, frameworkObject
    end
    
    -- Try QBox first (newer)
    if GetResourceState('qbox_core') == 'started' then
        frameworkType = 'qbox'
        frameworkObject = exports.qbox_core:GetCoreObject()
        if Config.Debug then
            print('[CCSkim] Detected QBox framework')
        end
    -- Try QBCore
    elseif GetResourceState('qb-core') == 'started' then
        frameworkType = 'qb'
        frameworkObject = exports['qb-core']:GetCoreObject()
        if Config.Debug then
            print('[CCSkim] Detected QBCore framework')
        end
    else
        -- Fallback to QBCore (most common)
        frameworkType = 'qb'
        frameworkObject = exports['qb-core']:GetCoreObject()
        if Config.Debug then
            print('[CCSkim] Defaulting to QBCore framework')
        end
    end
    
    return frameworkType, frameworkObject
end

-- Get framework object
function Framework.GetObject()
    if not frameworkObject then
        Framework.Detect()
    end
    return frameworkObject
end

-- Get player
function Framework.GetPlayer(source)
    local core = Framework.GetObject()
    if not core then return nil end
    
    if frameworkType == 'qbox' then
        return core:GetPlayer(source)
    else
        return core.Functions.GetPlayer(source)
    end
end

-- Create callback
function Framework.CreateCallback(name, callback)
    local core = Framework.GetObject()
    if not core then return end
    
    if frameworkType == 'qbox' then
        core:CreateCallback(name, callback)
    else
        core.Functions.CreateCallback(name, callback)
    end
end

-- Add command
function Framework.AddCommand(name, description, args, restricted, callback, permission)
    local core = Framework.GetObject()
    if not core then return end
    
    if frameworkType == 'qbox' then
        core:AddCommand(name, description, args, restricted, callback, permission)
    else
        core.Commands.Add(name, description, args, restricted, callback, permission)
    end
end

-- Check permission
function Framework.HasPermission(source, permission)
    local core = Framework.GetObject()
    if not core then return false end
    
    if frameworkType == 'qbox' then
        return core:HasPermission(source, permission)
    else
        return core.Functions.HasPermission(source, permission)
    end
end

-- Notify player
function Framework.Notify(source, message, type, duration)
    local core = Framework.GetObject()
    if not core then return end
    
    if frameworkType == 'qbox' then
        core:Notify(source, message, type, duration)
    else
        TriggerClientEvent('QBCore:Notify', source, message, type, duration)
    end
end

-- Get player data field (handles differences)
function Framework.GetPlayerDataField(player, field)
    if not player or not player.PlayerData then return nil end
    
    -- Both frameworks use PlayerData, but field access might differ
    if field == 'citizenid' then
        return player.PlayerData.citizenid or player.PlayerData.cid
    elseif field == 'name' then
        return player.PlayerData.name or (player.PlayerData.charinfo and player.PlayerData.charinfo.firstname .. ' ' .. player.PlayerData.charinfo.lastname)
    end
    
    return player.PlayerData[field]
end

-- Initialize on resource start
CreateThread(function()
    Wait(1000) -- Wait for frameworks to load
    Framework.Detect()
end)

return Framework

