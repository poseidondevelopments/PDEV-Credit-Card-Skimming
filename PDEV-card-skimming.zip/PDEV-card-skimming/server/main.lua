-- ============================================
-- POSEIDON DEVELOPMENT - Main Server Script
-- Copyright (c) 2025 Poseidon Developments - All Rights Reserved
-- ============================================

local Framework = require 'server.framework'
local Security = require 'server.security'
local Cache = require 'server.cache'
local Banking = require 'server.banking'
local Limits = require 'server.limits'

-- Initialize framework
local Core = Framework.GetObject()

-- Helper Functions
local function GetPlayer(source)
    -- Security check
    local valid, err = Security.ValidateSource(source)
    if not valid then
        Security.LogEvent(source, 'Invalid Source', err)
        return nil
    end
    
    -- Check cache first
    local cached = Cache.GetPlayer(source)
    if cached then
        return cached
    end
    
    -- Get from framework and cache it
    local Player = Framework.GetPlayer(source)
    if Player then
        Cache.SetPlayer(source, Player)
    end
    return Player
end

local function HasItem(source, item, amount)
    amount = amount or 1
    
    -- Check cache first
    local cachedCount = Cache.GetItemCount(source, item)
    if cachedCount ~= nil then
        return cachedCount >= amount
    end
    
    local count = 0
    if exports.ox_inventory then
        count = exports.ox_inventory:GetItemCount(source, item)
    else
        local Player = GetPlayer(source)
        if not Player then return false end
        local itemData = Player.Functions.GetItemByName(item)
        count = itemData and itemData.amount or 0
    end
    
    -- Cache the result
    Cache.SetItemCount(source, item, count)
    return count >= amount
end

local function RemoveItem(source, item, amount)
    amount = amount or 1
    local success = false
    
    if exports.ox_inventory then
        success = exports.ox_inventory:RemoveItem(source, item, amount)
    else
        local Player = GetPlayer(source)
        if not Player then return false end
        success = Player.Functions.RemoveItem(item, amount)
    end
    
    -- Invalidate cache on item removal
    if success then
        Cache.InvalidateItem(source, item)
        Cache.InvalidateInventory(source)
    end
    
    return success
end

local function AddItem(source, item, amount, metadata)
    amount = amount or 1
    -- Add decay metadata for ox_inventory if enabled
    if Config.ItemDecay.Enabled and exports.ox_inventory and Config.ItemDecay.DecayTimes[item] and Config.ItemDecay.DecayTimes[item] > 0 then
        metadata = metadata or {}
        if not metadata.decay then -- Only add if not already set
            metadata.decay = os.time() + Config.ItemDecay.DecayTimes[item]
        end
    end
    local success = false
    
    if exports.ox_inventory then
        success = exports.ox_inventory:AddItem(source, item, amount, metadata)
    else
        local Player = GetPlayer(source)
        if not Player then return false end
        success = Player.Functions.AddItem(item, amount, false, metadata)
    end
    
    -- Invalidate cache on item addition
    if success then
        Cache.InvalidateItem(source, item)
        Cache.InvalidateInventory(source)
    end
    
    return success
end

local function AddBlackMoney(source, amount, reason)
    -- Use banking system handler
    return Banking.AddMoney(source, amount, reason or 'credit-card-injection')
end

-- Skim Card Callback
Framework.CreateCallback('ccskim:server:skimCard', function(source, cb, targetType, target)
    -- Security: Rate limiting
    local rateOk, rateErr = Security.CheckRateLimit(source)
    if not rateOk then
        Security.LogEvent(source, 'Rate Limit', rateErr)
        cb(false, rateErr)
        return
    end
    
    -- Security: Validate source
    local valid, err = Security.ValidateSource(source)
    if not valid then
        Security.LogEvent(source, 'Invalid Source', err)
        cb(false, 'Security validation failed')
        return
    end
    
    -- Security: Validate target type
    local typeOk, typeErr = Security.ValidateTargetType(targetType)
    if not typeOk then
        Security.LogEvent(source, 'Invalid Target Type', typeErr)
        cb(false, 'Invalid target')
        return
    end
    
    local Player = GetPlayer(source)
    if not Player then
        cb(false, 'Player not found')
        return
    end
    
    -- Validate player has skimmer
    if not HasItem(source, Config.Items.Skimmer) then
        cb(false, 'Missing required item')
        return
    end
    
    -- Check global limits (hourly/daily)
    local identifier = Framework.GetPlayerDataField(Player, 'citizenid')
    if not identifier then
        cb(false, 'Invalid player data')
        return
    end
    local canSkim, limitMessage = Limits.CanSkim(identifier)
    if not canSkim then
        if Config.Debug then
            print(string.format('[CCSkim] Player %s hit limit: %s', identifier, limitMessage or 'Unknown'))
        end
        cb(false, limitMessage)
        return
    end
    
    -- Check cooldown (server-side validation with cache)
    local cooldownKey = 'ccskim:cooldown:skim:' .. identifier
    local lastSkim = Cache.GetCooldown(cooldownKey)
    
    if not lastSkim then
        lastSkim = GetResourceKvpInt(cooldownKey) or 0
        Cache.SetCooldown(cooldownKey, lastSkim)
    end
    
    local currentTime = os.time()
    
    if currentTime - lastSkim < (Config.Skimming.Cooldown / 1000) then
        cb(false, 'Cooldown active')
        return
    end
    
    -- Set cooldown (both cache and KVP)
    Cache.SetCooldown(cooldownKey, currentTime)
    SetResourceKvpInt(cooldownKey, currentTime)
    
    -- Validate target
    if targetType == 'player' then
        -- Security: Validate target source
        local targetValid, targetErr = Security.ValidateSource(target)
        if not targetValid then
            Security.LogEvent(source, 'Invalid Target', targetErr)
            cb(false, 'Invalid target player')
            return
        end
        
        local TargetPlayer = GetPlayer(target)
        if not TargetPlayer then
            cb(false, 'Target player not found')
            return
        end
        
        -- Check if target is online and valid
        local targetPed = GetPlayerPed(target)
        if not targetPed or targetPed == 0 then
            cb(false, 'Target player not online')
            return
        end
        
        -- Security: Validate distance (server-side)
        local targetCoords = GetEntityCoords(targetPed)
        local distOk, distErr = Security.ValidateDistance(source, targetCoords, Config.Skimming.MinDistance)
        if not distOk then
            Security.LogEvent(source, 'Distance Validation Failed', distErr)
            cb(false, 'Too far away')
            return
        end
    elseif targetType == 'npc' then
        -- NPC validation - server can't validate NPC position easily, but we trust client for NPCs
        -- The client-side distance check should handle this
    end
    
    -- Generate card quality/tier
    local cardTier = nil
    if Config.CardQuality.Enabled then
        local totalWeight = 0
        for _, tier in ipairs(Config.CardQuality.Tiers) do
            totalWeight = totalWeight + tier.weight
        end
        local random = math.random(1, totalWeight)
        local currentWeight = 0
        for _, tier in ipairs(Config.CardQuality.Tiers) do
            currentWeight = currentWeight + tier.weight
            if random <= currentWeight then
                cardTier = tier
                break
            end
        end
    end
    
    -- Generate card metadata
    local cardData = {
        skimmedBy = Framework.GetPlayerDataField(Player, 'citizenid'),
        skimmedAt = os.time(),
        targetType = targetType,
        cardNumber = math.random(1000000000000000, 9999999999999999),
        expiryDate = os.date('%m/%y', os.time() + (365 * 24 * 60 * 60)),
        cvv = math.random(100, 999),
        quality = cardTier and cardTier.name or 'Standard',
        qualityLabel = cardTier and cardTier.label or 'Standard Card',
        estimatedValue = cardTier and math.random(cardTier.minValue, cardTier.maxValue) or math.random(Config.ATM.MinAmount, Config.ATM.MaxAmount),
        successChance = cardTier and cardTier.successChance or Config.ATM.SuccessChance,
    }
    
    -- Add decay metadata for ox_inventory
    if Config.ItemDecay.Enabled and exports.ox_inventory and Config.ItemDecay.DecayTimes[Config.Items.CreditCard] and Config.ItemDecay.DecayTimes[Config.Items.CreditCard] > 0 then
        cardData.decay = os.time() + Config.ItemDecay.DecayTimes[Config.Items.CreditCard]
    end
    
    -- Check if skimmer breaks
    local skimmerBreaks = false
    if Config.Skimming.BreakChance and Config.Skimming.BreakChance > 0 then
        local breakRoll = math.random(100)
        if breakRoll <= Config.Skimming.BreakChance then
            skimmerBreaks = true
            -- Remove the skimmer
            local removed = RemoveItem(source, Config.Items.Skimmer, 1)
            if removed then
                Framework.Notify(source, 'Your card skimmer broke and was destroyed!', 'error')
                if Config.Debug then
                    print(string.format('[CCSkim] Player %s skimmer broke during use', source))
                end
            end
        end
    end
    
    -- Add credit card to inventory
    local success = AddItem(source, Config.Items.CreditCard, 1, cardData)
    
    if success then
        -- Record the skim (counts towards limits)
        Limits.RecordSkim(identifier)
        
        -- Notify player of card quality
        local qualityText = cardData.qualityLabel or 'Standard Card'
        local valueText = string.format('$%d - $%d', cardTier and cardTier.minValue or Config.ATM.MinAmount, cardTier and cardTier.maxValue or Config.ATM.MaxAmount)
        Framework.Notify(source, string.format('Successfully skimmed a %s!', qualityText), 'success')
        Framework.Notify(source, string.format('Estimated Value: %s', valueText), 'info')
        
        if Config.Debug then
            local name = Framework.GetPlayerDataField(Player, 'name')
            local citizenid = Framework.GetPlayerDataField(Player, 'citizenid')
            local breakInfo = skimmerBreaks and ' (Skimmer broke!)' or ''
            print(string.format('[CCSkim] Player %s (%s) successfully skimmed a %s%s', name or 'Unknown', citizenid or 'Unknown', qualityText, breakInfo))
        end
        cb(true)
    else
        cb(false)
    end
end)

-- Inject Card Callback
Framework.CreateCallback('ccskim:server:injectCard', function(source, cb)
    -- Wrap in error handler to catch any errors
    local success, err = xpcall(function()
        -- Security: Rate limiting
    local rateOk, rateErr = Security.CheckRateLimit(source)
    if not rateOk then
        Security.LogEvent(source, 'Rate Limit', rateErr)
        cb(false, 0)
        return
    end
    
    -- Security: Validate source
    local valid, err = Security.ValidateSource(source)
    if not valid then
        Security.LogEvent(source, 'Invalid Source', err)
        cb(false, 0)
        return
    end
    
    local Player = GetPlayer(source)
    if not Player then
        cb(false, 0)
        return
    end
    
    -- Validate player has required items
    if not HasItem(source, Config.Items.CreditCard) then
        cb(false, 0)
        return
    end
    
    if not HasItem(source, Config.Items.CardReader) then
        cb(false, 0)
        return
    end
    
    -- Check cooldown (server-side validation with cache)
    local identifier = Framework.GetPlayerDataField(Player, 'citizenid')
    if not identifier then
        cb(false, 0)
        return
    end
    local cooldownKey = 'ccskim:cooldown:inject:' .. identifier
    local lastInject = Cache.GetCooldown(cooldownKey)
    
    if not lastInject then
        lastInject = GetResourceKvpInt(cooldownKey) or 0
        Cache.SetCooldown(cooldownKey, lastInject)
    end
    
    local currentTime = os.time()
    
    if currentTime - lastInject < (Config.ATM.Cooldown / 1000) then
        cb(false, 0)
        return
    end
    
    -- Set cooldown (both cache and KVP)
    Cache.SetCooldown(cooldownKey, currentTime)
    SetResourceKvpInt(cooldownKey, currentTime)
    
    -- Find credit card in inventory (optimized with cache)
    local cardFound = false
    local cardMetadata = nil
    
    if exports.ox_inventory then
        -- Check if player has the item
        local itemCount = exports.ox_inventory:GetItemCount(source, Config.Items.CreditCard)
        if itemCount and itemCount > 0 then
            cardFound = true
            -- For ox_inventory, we'll get metadata when we remove the item
            -- For now, set empty metadata - it will be preserved when we remove/add the item
            cardMetadata = {}
        end
    else
        -- Use cached player data
        local items = Player.PlayerData.items
        for i = 1, #items do
            local item = items[i]
            if item.name == Config.Items.CreditCard and item.amount > 0 then
                cardFound = true
                cardMetadata = item.info or item.metadata
                break
            end
        end
    end
    
    if not cardFound then
        cb(false, 0)
        return
    end
    
    -- Calculate black money amount based on card quality
    local amount = Config.ATM.MinAmount
    local cardQuality = cardMetadata and cardMetadata.quality or nil
    local successChance = Config.ATM.SuccessChance
    local qualityAlertMultiplier = 1.0
    
    if Config.CardQuality.Enabled and cardQuality and cardMetadata.estimatedValue then
        -- Use card's estimated value from quality system
        amount = cardMetadata.estimatedValue
        successChance = cardMetadata.successChance or Config.ATM.SuccessChance
        if Config.ATM.QualityAlertMultiplier[cardQuality] then
            qualityAlertMultiplier = Config.ATM.QualityAlertMultiplier[cardQuality]
        end
    else
        -- Fallback to random amount
        amount = math.random(Config.ATM.MinAmount, Config.ATM.MaxAmount)
    end
    
    -- Check if card has expired (decay system)
    if Config.ItemDecay.Enabled and cardMetadata.decay then
        local currentTime = os.time()
        if currentTime >= cardMetadata.decay then
            cb(false, 0)
            Framework.Notify(source, 'This card has expired and is no longer usable', 'error')
            return
        end
    end
    
    -- Security: Validate amount
    local amountOk, amountErr = Security.ValidateAmount(amount)
    if not amountOk then
        Security.LogEvent(source, 'Invalid Amount', amountErr)
        cb(false, 0)
        return
    end
    
    -- Remove credit card (metadata will be preserved from cardMetadata we set earlier)
    local removed = RemoveItem(source, Config.Items.CreditCard, 1)
    
    if not removed then
        cb(false, 0)
        return
    end
    
    -- Check success based on card quality
    local injectionSuccess = math.random(100) <= successChance
    
    if not injectionSuccess then
        -- Injection failed - card is consumed (not returned)
        cb(false, 0)
        Framework.Notify(source, 'Card injection failed! The ATM detected the fraud and the card was destroyed.', 'error')
        return
    end
    
    -- Add black money using banking system
    print(string.format('[CCSkim DEBUG] Attempting to add $%d to player %s (PaymentType: %s)', amount, source, Config.Banking.PaymentType or 'black_money'))
    
    local moneyAdded = AddBlackMoney(source, amount, 'credit-card-injection')
    
    print(string.format('[CCSkim DEBUG] AddBlackMoney returned: %s', tostring(moneyAdded)))
    
    if moneyAdded then
        -- Invalidate player cache after money addition
        Cache.InvalidatePlayer(source)
        
        if Config.Debug then
            local name = Framework.GetPlayerDataField(Player, 'name')
            local citizenid = Framework.GetPlayerDataField(Player, 'citizenid')
            local qualityInfo = cardQuality and (' (' .. cardQuality .. ')') or ''
            print(string.format('[CCSkim] Player %s (%s) successfully injected a card%s and received $%d', 
                name or 'Unknown', citizenid or 'Unknown', qualityInfo, amount))
        end
        
        -- Log the transaction (optional)
        local name = Framework.GetPlayerDataField(Player, 'name')
        local citizenid = Framework.GetPlayerDataField(Player, 'citizenid')
        TriggerEvent('qb-log:server:CreateLog', 'ccskim', 'Card Injection', 'green', 
            string.format('%s (%s) injected a %s card and received $%d', 
                name or 'Unknown', citizenid or 'Unknown', cardQuality or 'Standard', amount))
        
        cb(true, amount, cardQuality, qualityAlertMultiplier)
    else
        print(string.format('[CCSkim ERROR] Failed to add payment to player %s - returning card', source))
        -- Return card if money addition failed
        AddItem(source, Config.Items.CreditCard, 1, cardMetadata)
        Framework.Notify(source, 'Failed to process payment - card returned to inventory', 'error')
        cb(false, 0)
    end
    end, function(err)
        -- Error handler for xpcall
        print(string.format('[CCSkim CRITICAL ERROR] Callback execution failed: %s', tostring(err)))
        print(debug.traceback())
        cb(false, 0)
    end)
    
    if not success then
        print(string.format('[CCSkim] Callback failed, error: %s', tostring(err)))
    end
end)

-- Admin command to give items (optional, for testing)
Framework.AddCommand('ccskim_give', 'Give credit card skimming items (Admin Only)', {
    {name = 'id', help = 'Player ID'},
    {name = 'item', help = 'Item name (skimmer, card, reader)'},
    {name = 'amount', help = 'Amount (default: 1)'}
}, true, function(source, args)
    local Player = GetPlayer(source)
    if not Player then return end
    
    -- Check admin permission
    if not Framework.HasPermission(source, 'admin') then
        Framework.Notify(source, 'You don\'t have permission to use this command', 'error')
        return
    end
    
    local targetId = tonumber(args[1])
    local itemName = args[2]
    local amount = tonumber(args[3]) or 1
    
    -- Security: Validate inputs
    if not targetId or targetId < 0 or targetId > 65535 then
        Framework.Notify(source, 'Invalid player ID', 'error')
        return
    end
    
    if not itemName or type(itemName) ~= 'string' then
        Framework.Notify(source, 'Invalid item name', 'error')
        return
    end
    
    -- Security: Validate amount
    if amount < 1 or amount > 100 then
        Framework.Notify(source, 'Invalid amount (1-100)', 'error')
        return
    end
    
    if not targetId or not itemName then
        Framework.Notify(source, 'Usage: /ccskim_give [id] [item] [amount]', 'error')
        return
    end
    
    local itemMap = {
        ['skimmer'] = Config.Items.Skimmer,
        ['card'] = Config.Items.CreditCard,
        ['reader'] = Config.Items.CardReader,
    }
    
    local item = itemMap[itemName:lower()]
    if not item then
        Framework.Notify(source, 'Invalid item. Use: skimmer, card, or reader', 'error')
        return
    end
    
    -- Security: Validate item name
    local itemOk, itemErr = Security.ValidateItemName(item)
    if not itemOk then
        Framework.Notify(source, 'Invalid item', 'error')
        return
    end
    
    local success = AddItem(targetId, item, amount)
    if success then
        Framework.Notify(source, 'Item given successfully', 'success')
        Framework.Notify(targetId, 'You received ' .. amount .. 'x ' .. item, 'success')
    else
        Framework.Notify(source, 'Failed to give item', 'error')
    end
end, 'admin')

-- Player disconnect cleanup
AddEventHandler('playerDropped', function()
    local source = source
    Cache.ClearPlayer(source)
end)

-- Cleanup on resource stop
AddEventHandler('onResourceStop', function(resourceName)
    if GetCurrentResourceName() == resourceName then
        Cache.ClearAll()
    end
end)


-- Admin command to check player limits
Framework.AddCommand('ccskim_limits', 'Check credit card skimming limits for a player', {
    {name = 'id', help = 'Player ID (leave empty for self)'}
}, false, function(source, args)
    local Player = GetPlayer(source)
    if not Player then return end
    
    if not Framework.HasPermission(source, 'admin') then
        Framework.Notify(source, 'You don\'t have permission to use this command', 'error')
        return
    end
    
    local targetId = tonumber(args[1]) or source
    local TargetPlayer = GetPlayer(targetId)
    
    if not TargetPlayer then
        Framework.Notify(source, 'Player not found', 'error')
        return
    end
    
    local citizenid = Framework.GetPlayerDataField(TargetPlayer, 'citizenid')
    local hourly, daily = Limits.GetRemaining(citizenid)
    local hourlyUsed = Config.Skimming.MaxPerHour - hourly
    local dailyUsed = Config.Skimming.MaxPerDay - daily
    
    Framework.Notify(source, 
        string.format('Player: %s\nHourly: %d/%d\nDaily: %d/%d', 
            TargetPlayer.PlayerData.name, hourlyUsed, Config.Skimming.MaxPerHour, dailyUsed, Config.Skimming.MaxPerDay), 
        'primary', 10000)
end, 'admin')

-- Admin command to reset player limits
Framework.AddCommand('ccskim_reset', 'Reset credit card skimming limits for a player', {
    {name = 'id', help = 'Player ID (leave empty for all players)'}
}, false, function(source, args)
    local Player = GetPlayer(source)
    if not Player then return end
    
    if not Framework.HasPermission(source, 'admin') then
        Framework.Notify(source, 'You don\'t have permission to use this command', 'error')
        return
    end
    
    local targetId = tonumber(args[1])
    
    if targetId then
        local TargetPlayer = GetPlayer(targetId)
        if TargetPlayer then
            local citizenid = Framework.GetPlayerDataField(TargetPlayer, 'citizenid')
            local name = Framework.GetPlayerDataField(TargetPlayer, 'name')
            Limits.ClearPlayer(citizenid)
            Framework.Notify(source, 'Limits reset for ' .. (name or 'Player'), 'success')
        else
            Framework.Notify(source, 'Player not found', 'error')
        end
    else
        Limits.ClearPlayer()
        Framework.Notify(source, 'All limits reset', 'success')
    end
end, 'admin')

-- Note: ox_inventory doesn't support RegisterItem export
-- Card quality is shown via notifications when skimming and in item metadata
-- Players can see quality in the item description when viewing the card in inventory

-- Debug command to check cache stats
if Config.Debug then
    Framework.AddCommand('ccskim_cache', 'Check cache statistics (Debug)', {}, false, function(source, args)
        local stats = Cache.GetStats()
        local limitStats = Limits.GetStats()
        print(string.format('[CCSkim Cache] Players: %d, Items: %d, Inventories: %d, Cooldowns: %d', 
            stats.players, stats.items, stats.inventories, stats.cooldowns))
        print(string.format('[CCSkim Limits] Hourly: %d, Daily: %d', limitStats.hourly, limitStats.daily))
    end, 'admin')
end

