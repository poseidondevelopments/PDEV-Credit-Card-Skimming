-- ============================================
-- POSEIDON DEVELOPMENT - Global Limits System
-- Copyright (c) 2025 Poseidon Developments - All Rights Reserved
-- ============================================

local Limits = {}

-- Cache for limits tracking
local hourlyLimits = {} -- {citizenid: {count, resetTime}}
local dailyLimits = {} -- {citizenid: {count, resetDate}}

-- Initialize daily reset thread
CreateThread(function()
    while true do
        Wait(60000) -- Check every minute
        Limits.CheckDailyReset()
    end
end)

-- Check if player can skim (hourly and daily limits)
function Limits.CanSkim(citizenid)
    if not citizenid then return false, 'Invalid player' end
    
    local currentTime = os.time()
    
    -- Check hourly limit
    local hourly = hourlyLimits[citizenid]
    if hourly then
        if currentTime < hourly.resetTime then
            if hourly.count >= Config.Skimming.MaxPerHour then
                local remaining = hourly.resetTime - currentTime
                local minutes = math.ceil(remaining / 60)
                return false, string.format('Hourly limit reached. Wait %d minute(s)', minutes)
            end
        else
            -- Reset hourly limit
            hourlyLimits[citizenid] = nil
        end
    end
    
    -- Check daily limit
    local daily = dailyLimits[citizenid]
    local today = os.date('%Y-%m-%d')
    
    if daily then
        if daily.date == today then
            if daily.count >= Config.Skimming.MaxPerDay then
                return false, 'Daily limit reached. Try again tomorrow.'
            end
        else
            -- Reset daily limit (new day)
            dailyLimits[citizenid] = nil
        end
    end
    
    return true, nil
end

-- Record a skim attempt
function Limits.RecordSkim(citizenid)
    if not citizenid then return end
    
    local currentTime = os.time()
    
    -- Update hourly limit
    local hourly = hourlyLimits[citizenid]
    if hourly and currentTime < hourly.resetTime then
        hourly.count = hourly.count + 1
    else
        hourlyLimits[citizenid] = {
            count = 1,
            resetTime = currentTime + Config.Skimming.ResetTime
        }
    end
    
    -- Update daily limit
    local today = os.date('%Y-%m-%d')
    local daily = dailyLimits[citizenid]
    
    if daily and daily.date == today then
        daily.count = daily.count + 1
    else
        dailyLimits[citizenid] = {
            count = 1,
            date = today
        }
    end
end

-- Check daily reset (runs at configured hour)
function Limits.CheckDailyReset()
    local currentHour = tonumber(os.date('%H'))
    if currentHour == Config.Skimming.DailyResetHour then
        -- Reset all daily limits
        dailyLimits = {}
        if Config.Debug then
            print('[CCSkim] Daily limits reset')
        end
    end
end

-- Get remaining skims for player
function Limits.GetRemaining(citizenid)
    if not citizenid then return 0, 0 end
    
    local hourly = 0
    local daily = 0
    
    local hourlyData = hourlyLimits[citizenid]
    if hourlyData and os.time() < hourlyData.resetTime then
        hourly = math.max(0, Config.Skimming.MaxPerHour - hourlyData.count)
    else
        hourly = Config.Skimming.MaxPerHour
    end
    
    local today = os.date('%Y-%m-%d')
    local dailyData = dailyLimits[citizenid]
    if dailyData and dailyData.date == today then
        daily = math.max(0, Config.Skimming.MaxPerDay - dailyData.count)
    else
        daily = Config.Skimming.MaxPerDay
    end
    
    return hourly, daily
end

-- Clear limits for a player (admin function)
function Limits.ClearPlayer(citizenid)
    if citizenid then
        hourlyLimits[citizenid] = nil
        dailyLimits[citizenid] = nil
    else
        hourlyLimits = {}
        dailyLimits = {}
    end
end

-- Get limit stats (for debugging)
function Limits.GetStats()
    local hourlyCount = 0
    local dailyCount = 0
    
    for _ in pairs(hourlyLimits) do hourlyCount = hourlyCount + 1 end
    for _ in pairs(dailyLimits) do dailyCount = dailyCount + 1 end
    
    return {
        hourly = hourlyCount,
        daily = dailyCount
    }
end

return Limits

