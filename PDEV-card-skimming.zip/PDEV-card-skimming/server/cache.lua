-- ============================================
-- POSEIDON DEVELOPMENT - Local Caching System
-- Copyright (c) 2025 Poseidon Developments - All Rights Reserved
-- ============================================

local Cache = {}

-- Cache tables
local playerCache = {}
local itemCache = {}
local cooldownCache = {}
local inventoryCache = {}

-- Cache expiration times (in seconds)
local CACHE_EXPIRATION = {
    Player = 30,      -- 30 seconds
    Item = 60,         -- 60 seconds
    Inventory = 10,   -- 10 seconds
    Cooldown = 0,      -- No expiration (managed separately)
}

-- Initialize cache cleanup thread
CreateThread(function()
    while true do
        Wait(30000) -- Check every 30 seconds
        Cache.Cleanup()
    end
end)

-- Cleanup expired cache entries
function Cache.Cleanup()
    local currentTime = os.time()
    
    -- Clean player cache
    for source, data in pairs(playerCache) do
        if data.expires and currentTime > data.expires then
            playerCache[source] = nil
        end
    end
    
    -- Clean item cache
    for key, data in pairs(itemCache) do
        if data.expires and currentTime > data.expires then
            itemCache[key] = nil
        end
    end
    
    -- Clean inventory cache
    for source, data in pairs(inventoryCache) do
        if data.expires and currentTime > data.expires then
            inventoryCache[source] = nil
        end
    end
end

-- Get cached player data
function Cache.GetPlayer(source)
    local cached = playerCache[source]
    if cached and cached.expires and os.time() < cached.expires then
        return cached.data
    end
    return nil
end

-- Set cached player data
function Cache.SetPlayer(source, data)
    playerCache[source] = {
        data = data,
        expires = os.time() + CACHE_EXPIRATION.Player
    }
end

-- Invalidate player cache
function Cache.InvalidatePlayer(source)
    playerCache[source] = nil
end

-- Get cached item count
function Cache.GetItemCount(source, item)
    local key = source .. ':' .. item
    local cached = itemCache[key]
    if cached and cached.expires and os.time() < cached.expires then
        return cached.data
    end
    return nil
end

-- Set cached item count
function Cache.SetItemCount(source, item, count)
    local key = source .. ':' .. item
    itemCache[key] = {
        data = count,
        expires = os.time() + CACHE_EXPIRATION.Item
    }
end

-- Invalidate item cache for player
function Cache.InvalidateItem(source, item)
    local key = source .. ':' .. item
    itemCache[key] = nil
end

-- Invalidate all item cache for player
function Cache.InvalidateAllItems(source)
    for key, _ in pairs(itemCache) do
        if string.find(key, tostring(source) .. ':') == 1 then
            itemCache[key] = nil
        end
    end
end

-- Get cached inventory
function Cache.GetInventory(source)
    local cached = inventoryCache[source]
    if cached and cached.expires and os.time() < cached.expires then
        return cached.data
    end
    return nil
end

-- Set cached inventory
function Cache.SetInventory(source, inventory)
    inventoryCache[source] = {
        data = inventory,
        expires = os.time() + CACHE_EXPIRATION.Inventory
    }
end

-- Invalidate inventory cache
function Cache.InvalidateInventory(source)
    inventoryCache[source] = nil
end

-- Get cached cooldown
function Cache.GetCooldown(key)
    return cooldownCache[key]
end

-- Set cached cooldown
function Cache.SetCooldown(key, value)
    cooldownCache[key] = value
end

-- Clear all cache for a player (when they disconnect)
function Cache.ClearPlayer(source)
    Cache.InvalidatePlayer(source)
    Cache.InvalidateAllItems(source)
    Cache.InvalidateInventory(source)
end

-- Clear all caches
function Cache.ClearAll()
    playerCache = {}
    itemCache = {}
    inventoryCache = {}
    cooldownCache = {}
end

-- Get cache stats (for debugging)
function Cache.GetStats()
    local stats = {
        players = 0,
        items = 0,
        inventories = 0,
        cooldowns = 0
    }
    
    for _ in pairs(playerCache) do stats.players = stats.players + 1 end
    for _ in pairs(itemCache) do stats.items = stats.items + 1 end
    for _ in pairs(inventoryCache) do stats.inventories = stats.inventories + 1 end
    for _ in pairs(cooldownCache) do stats.cooldowns = stats.cooldowns + 1 end
    
    return stats
end

return Cache

