-- ============================================
-- POSEIDON DEVELOPMENT - Banking System Handler
-- Copyright (c) 2025 Poseidon Developments - All Rights Reserved
-- ============================================

local Framework = require 'server.framework'
local Banking = {}

-- Cache for banking system detection
local bankingSystemCache = nil
local bankingSystemChecked = false

-- Detect which banking system is available
function Banking.DetectBankingSystem()
    if bankingSystemChecked then
        return bankingSystemCache
    end
    
    bankingSystemChecked = true
    
    if Config.Banking.System == 'auto' then
        -- Auto-detect banking system
        if GetResourceState('okokBanking') == 'started' then
            bankingSystemCache = 'okok'
            if Config.Debug then
                print('[CCSkim] Detected okokBanking system')
            end
        elseif GetResourceState('qb-banking') == 'started' then
            bankingSystemCache = 'qb'
            if Config.Debug then
                print('[CCSkim] Detected qb-banking system')
            end
        else
            bankingSystemCache = 'item'
            if Config.Debug then
                print('[CCSkim] No banking system detected, using black_money item')
            end
        end
    else
        bankingSystemCache = Config.Banking.System
    end
    
    return bankingSystemCache
end

-- Add money to player (based on PaymentType config)
function Banking.AddMoney(source, amount, reason)
    if not source or not amount or amount <= 0 then
        print(string.format('[CCSkim ERROR] AddMoney: Invalid parameters - source: %s, amount: %s', tostring(source), tostring(amount)))
        return false
    end
    
    local paymentType = Config.Banking.PaymentType or 'black_money'
    print(string.format('[CCSkim DEBUG] AddMoney called - source: %s, amount: %d, paymentType: %s', source, amount, paymentType))
    
    -- Handle different payment types
    if paymentType == 'black_money' then
        print('[CCSkim DEBUG] Using AddBlackMoneyItem')
        return Banking.AddBlackMoneyItem(source, amount)
    elseif paymentType == 'cash' then
        print('[CCSkim DEBUG] Using AddCash')
        return Banking.AddCash(source, amount, reason)
    elseif paymentType == 'bank' then
        print('[CCSkim DEBUG] Using bank payment')
        local system = Banking.DetectBankingSystem()
        if system == 'okok' then
            return Banking.AddMoneyOkok(source, amount, reason)
        elseif system == 'qb' then
            return Banking.AddMoneyQB(source, amount, reason)
        else
            -- Fallback to cash if banking system not found
            print(string.format('[CCSkim] Banking system not found, falling back to cash for player %s', source))
            return Banking.AddCash(source, amount, reason)
        end
    else
        -- Invalid payment type, default to black_money
        print(string.format('[CCSkim ERROR] Invalid PaymentType "%s", defaulting to black_money', paymentType))
        return Banking.AddBlackMoneyItem(source, amount)
    end
end

-- Add cash money to player
function Banking.AddCash(source, amount, reason)
    local Player = Framework.GetPlayer(source)
    if not Player then 
        print(string.format('[CCSkim ERROR] AddCash: Player not found for source %s', source))
        return false 
    end
    
    local success = Player.Functions.AddMoney('cash', amount, reason or 'credit-card-injection')
    
    if success then
        print(string.format('[CCSkim] Successfully added $%d cash to player %s', amount, source))
        return true
    else
        print(string.format('[CCSkim ERROR] Failed to add $%d cash to player %s', amount, source))
        return false
    end
end

-- Add money using okok banking
function Banking.AddMoneyOkok(source, amount, reason)
    if not exports.okokBanking then
        if Config.Debug then
            print('[CCSkim] okokBanking export not found, falling back to item')
        end
        return Banking.AddBlackMoneyItem(source, amount)
    end
    
    local success = false
    
    -- Try different okok banking export methods
    if exports.okokBanking.AddMoney then
        success = exports.okokBanking:AddMoney(source, amount, Config.Banking.AccountType or 'savings')
    elseif exports.okokBanking.AddAccountMoney then
        success = exports.okokBanking:AddAccountMoney(source, amount, Config.Banking.AccountType or 'savings')
    elseif exports['okokBanking'] then
        -- Try direct export
        local result = exports['okokBanking']:AddMoney(source, amount, Config.Banking.AccountType or 'savings')
        success = result == true or result == 1
    end
    
    if success then
        if Config.Debug then
            print(string.format('[CCSkim] Added $%d to player %s via okokBanking', amount, source))
        end
        return true
    else
        if Config.Debug then
            print('[CCSkim] Failed to add money via okokBanking, falling back to item')
        end
        return Banking.AddBlackMoneyItem(source, amount)
    end
end

-- Add money using qb banking
function Banking.AddMoneyQB(source, amount, reason)
    local Player = Framework.GetPlayer(source)
    
    if not Player then
        if Config.Debug then
            print('[CCSkim] Player not found for qb banking')
        end
        return false
    end
    
    -- Try qb-banking export first
    if exports['qb-banking'] and exports['qb-banking'].AddMoney then
        local success = exports['qb-banking']:AddMoney(source, amount)
        if success then
            if Config.Debug then
                print(string.format('[CCSkim] Added $%d to player %s via qb-banking', amount, source))
            end
            return true
        end
    end
    
    -- Fallback to QBCore AddMoney
    local success = Player.Functions.AddMoney('bank', amount, reason or 'credit-card-injection')
    
    if success then
        if Config.Debug then
            print(string.format('[CCSkim] Added $%d to player %s via QBCore banking', amount, source))
        end
        return true
    else
        if Config.Debug then
            print('[CCSkim] Failed to add money via qb banking, falling back to item')
        end
        return Banking.AddBlackMoneyItem(source, amount)
    end
end

-- Add black_money item
function Banking.AddBlackMoneyItem(source, amount)
    if not source or not amount or amount <= 0 then
        print(string.format('[CCSkim ERROR] AddBlackMoneyItem: Invalid parameters - source: %s, amount: %s', tostring(source), tostring(amount)))
        return false
    end
    
    if exports.ox_inventory then
        print(string.format('[CCSkim DEBUG] Using ox_inventory, trying to add %d of item "%s" to player %s', amount, Config.BlackMoney.ItemName, source))
        
        -- Try to add item directly
        local success = exports.ox_inventory:AddItem(source, Config.BlackMoney.ItemName, amount)
        
        if success then
            print(string.format('[CCSkim] Successfully added %d %s item to player %s', amount, Config.BlackMoney.ItemName, source))
            return true
        else
            print(string.format('[CCSkim ERROR] Failed to add %d %s item to player %s - AddItem returned false/nil. Check: 1) Item exists in database, 2) Inventory has space, 3) Item limits', amount, Config.BlackMoney.ItemName, source))
            -- Notify player of failure
            Framework.Notify(source, string.format('Failed to add %d %s - check inventory space', amount, Config.BlackMoney.ItemName), 'error')
            return false
        end
    else
        local Player = Framework.GetPlayer(source)
        if not Player then 
            if Config.Debug then
                print(string.format('[CCSkim] AddBlackMoneyItem: Player not found for source %s', source))
            end
            return false 
        end
        
        local success = false
        if Framework.Detect() == 'qbox' then
            success = Player.Functions.AddMoney('black_money', amount)
        else
            success = Player.Functions.AddMoney('black_money', amount)
        end
        
        if success then
            if Config.Debug then
                print(string.format('[CCSkim] Added $%d black_money to player %s', amount, source))
            end
            return true
        else
            if Config.Debug then
                print(string.format('[CCSkim] Failed to add $%d black_money to player %s', amount, source))
            end
            return false
        end
    end
end

-- Get player bank balance (for display purposes)
function Banking.GetBalance(source)
    local system = Banking.DetectBankingSystem()
    
    if system == 'okok' then
        if exports.okokBanking and exports.okokBanking.GetAccount then
            local account = exports.okokBanking:GetAccount(source)
            if account then
                return account[Config.Banking.AccountType or 'savings'] or 0
            end
        end
    elseif system == 'qb' then
        local Player = Framework.GetPlayer(source)
        if Player then
            return Player.PlayerData.money.bank or 0
        end
    end
    
    return 0
end

return Banking

