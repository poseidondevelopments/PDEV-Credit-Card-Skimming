-- ============================================
-- POSEIDON DEVELOPMENT - Credit Card Skimming Script
-- Copyright (c) 2025 Poseidon Developments - All Rights Reserved
-- ============================================

-- ============================================
-- CONFIGURATION GUIDE
-- ============================================
-- IMPORTANT: Read this section before changing 'auto' settings
--
-- FRAMEWORK SETTING (Config.Framework):
--   'auto' = Automatically detects QBCore or QBox (RECOMMENDED)
--   'qb' = Force QBCore framework
--   'qbox' = Force QBox framework
--   → Only change if auto-detection fails
--
-- DISPATCH SYSTEM (Config.Dispatch.System):
--   'auto' = Automatically detects your dispatch system (RECOMMENDED)
--   'rcore' = Use rcore_dispatch
--   'lb' = Use lb-phone dispatch
--   'wasabi' = Use wasabi_dispatch
--   'cd' = Use cd_dispatch
--   'none' = Disable dispatch alerts
--   → Only change if auto-detection fails or you want to disable alerts
--
-- PAYMENT TYPE (Config.Banking.PaymentType):
--   'black_money' = Players receive black_money items when injecting cards (DEFAULT - Recommended)
--   'cash' = Players receive normal cash money
--   'bank' = Players receive money in their bank account (requires banking system)
--   → Change this to switch between black_money items, cash, or bank money
--
-- BANKING SYSTEM (Config.Banking.System):
--   Only used if PaymentType = 'bank'
--   'auto' = Automatically detects your banking system (RECOMMENDED)
--   'okok' = Use okokBanking
--   'qb' = Use qb-banking or QBCore banking
--   → Only change if auto-detection fails
-- ============================================

Config = {}

Config.Debug = false  -- Set to true to see debug messages, then set back to false when done
-- Framework Detection: 'auto' (auto-detect), 'qb' (QBCore), 'qbox' (QBox)
-- RECOMMENDED: Leave as 'auto' - it will automatically detect your framework
-- Only change if auto-detection fails or you want to force a specific framework
Config.Framework = 'auto'

Config.Skimming = {
    Duration = 5000,
    MinDistance = 2.0,
    Cooldown = 5000, -- Reduced from 30000 (30 seconds) to 5000 (5 seconds) - time between skims
    SuccessChance = 85,
    AlertChance = 100,
    MaxPerHour = 10, -- Maximum 10 cards per hour
    MaxPerDay = 50, -- Maximum 50 cards per day
    ResetTime = 3600, -- Hourly limit resets every 3600 seconds (1 hour)
    DailyResetHour = 0, -- Daily limit resets at midnight (hour 0)
    -- Skimmer break chance (percentage per use)
    -- Set to 0 to disable break chance
    BreakChance = 5, -- 5% chance to break per use
}

Config.ATM = {
    Duration = 10000,
    MinDistance = 2.0,
    Cooldown = 30000, -- 30 seconds between injections
    SuccessChance = 75, -- Base success chance (modified by card quality)
    MinAmount = 500, -- Fallback if quality system disabled
    MaxAmount = 5000, -- Fallback if quality system disabled
    AlertChance = 30,
    -- Quality multiplier: Higher quality = higher alert chance
    QualityAlertMultiplier = {
        Bronze = 1.0, -- 100% of base alert chance
        Silver = 1.2, -- 120% of base alert chance
        Gold = 1.5, -- 150% of base alert chance
        Platinum = 2.0, -- 200% of base alert chance
        Black = 3.0, -- 300% of base alert chance
    },
}

Config.Dispatch = {
    -- Dispatch System Configuration
    -- RECOMMENDED: Leave as 'auto' - it will automatically detect your dispatch system
    -- Options: 'auto', 'rcore', 'lb', 'wasabi', 'cd', 'none'
    -- 
    -- How to change:
    --   If using rcore_dispatch → Change to 'rcore'
    --   If using lb-phone → Change to 'lb'
    --   If using wasabi_dispatch → Change to 'wasabi'
    --   If using cd_dispatch → Change to 'cd'
    --   If you don't have a dispatch system → Change to 'none'
    --   If auto-detection works → Keep as 'auto' (RECOMMENDED)
    System = 'auto',
    AlertDistance = 50.0,
    AlertDuration = 30000,
    AlwaysAlertOnSkim = true,
    AlertOnSuccess = true,
    AlertOnFailure = true,
}

Config.Items = {
    Skimmer = 'card_skimmer',
    CreditCard = 'credit_card',
    CardReader = 'card_reader',
}

-- Card Quality/Tier System
Config.CardQuality = {
    Enabled = true,
    -- Card Tiers with value ranges and success chances
    Tiers = {
        {name = 'Bronze', label = 'Bronze Card', minValue = 500, maxValue = 1500, successChance = 90, weight = 40}, -- 40% chance
        {name = 'Silver', label = 'Silver Card', minValue = 1500, maxValue = 3000, successChance = 80, weight = 30}, -- 30% chance
        {name = 'Gold', label = 'Gold Card', minValue = 3000, maxValue = 5000, successChance = 70, weight = 20}, -- 20% chance
        {name = 'Platinum', label = 'Platinum Card', minValue = 5000, maxValue = 8000, successChance = 60, weight = 8}, -- 8% chance
        {name = 'Black', label = 'Black Card', minValue = 8000, maxValue = 15000, successChance = 50, weight = 2}, -- 2% chance
    },
    -- Quality colors for UI (hex codes)
    Colors = {
        Bronze = '#CD7F32',
        Silver = '#C0C0C0',
        Gold = '#FFD700',
        Platinum = '#E5E4E2',
        Black = '#000000',
    },
}

-- Item Decay Settings (ox_inventory)
Config.ItemDecay = {
    Enabled = true,
    -- Decay times in seconds (0 = no decay)
    DecayTimes = {
        card_skimmer = 0, -- No decay (equipment)
        credit_card = 172800, -- 48 hours (2 days)
        card_reader = 0, -- No decay (equipment)
    },
    -- Warning time before expiry (in seconds) - shows warning when item is about to expire
    WarningTime = 3600, -- 1 hour before expiry
}

Config.BlackMoney = {
    ItemName = 'black_money',
    MinPerCard = 500,
    MaxPerCard = 5000,
}

Config.Banking = {
    -- Banking System Configuration
    -- Payment Type: What players receive when injecting cards
    -- Options: 'black_money', 'cash', 'bank'
    --   'black_money' = Players receive black_money items (DEFAULT - Recommended for criminal activities)
    --   'cash' = Players receive normal cash money
    --   'bank' = Players receive money in their bank account (requires banking system)
    PaymentType = 'black_money',
    
    -- Banking System Detection (only used if PaymentType = 'bank')
    -- RECOMMENDED: Leave as 'auto' - it will automatically detect your banking system
    -- Options: 'auto', 'okok', 'qb'
    --   'auto' = Automatically detects okokBanking or qb-banking (RECOMMENDED)
    --   'okok' = Force okokBanking system
    --   'qb' = Force qb-banking or QBCore banking
    System = 'auto',
    
    -- Account Type for okokBanking only: 'savings' or 'checking'
    -- Only used if PaymentType = 'bank' and System = 'okok'
    AccountType = 'savings',
}

Config.Shop = {
    Enabled = true,
    Locations = {{
        coords = vector4(-47.0, -1757.0, 29.42, 50.0),
        pedModel = `s_m_y_dealer_01`,
        pedHeading = 50.0,
        pedScenario = 'WORLD_HUMAN_SMOKING',
        blip = {enabled = true, sprite = 52, color = 1, scale = 0.8, label = 'Illegal Equipment Shop'}
    }},
    Items = {{
        item = 'card_skimmer',
        label = 'Card Skimmer',
        description = 'A device used to skim credit card information from unsuspecting victims.',
        price = 5000,
        stock = -1,
        category = 'equipment'
    }, {
        item = 'card_reader',
        label = 'Card Reader',
        description = 'A device used to read and inject credit card data into ATMs.',
        price = 7500,
        stock = -1,
        category = 'equipment'
    }, {
        item = 'credit_card',
        label = 'Credit Card',
        description = 'A pre-loaded credit card (for testing purposes).',
        price = 2000,
        stock = -1,
        category = 'cards'
    }},
    Settings = {
        UseCash = true,
        UseBank = false,
        UseBlackMoney = false,
        AllowMultiple = true,
        ShowStock = true,
        Animation = {enabled = true, dict = 'mp_common', anim = 'givetake1_a', duration = 2000}
    }
}

Config.SkimTargets = {
    Models = {
        `mp_m_freemode_01`, `mp_f_freemode_01`, `s_m_y_cop_01`, `s_f_y_cop_01`, `s_m_y_swat_01`,
        `s_m_y_ammucity_01`, `s_m_y_barman_01`, `s_m_y_busboy_01`, `s_m_y_chef_01`, `s_m_y_clown_01`,
        `s_m_y_construct_01`, `s_m_y_construct_02`, `s_m_y_dealer_01`, `s_m_y_devinsec_01`,
        `s_m_y_dockwork_01`, `s_m_y_doorman_01`, `s_m_y_dwservice_01`, `s_m_y_dwservice_02`,
        `s_m_y_factory_01`, `s_m_y_garbage`, `s_m_y_grip_01`, `s_m_y_hwaycop_01`, `s_m_y_marine_01`,
        `s_m_y_marine_02`, `s_m_y_marine_03`, `s_m_m_paramedic_01`, `s_m_y_pilot_01`,
        `s_m_y_prismuscl_01`, `s_m_y_prisoner_01`, `s_m_y_ranger_01`, `s_m_y_robber_01`,
        `s_m_y_sheriff_01`, `s_m_y_shop_mask`, `s_m_y_swat_01`, `s_m_y_uscg_01`, `s_m_y_valet_01`,
        `s_m_y_waiter_01`, `s_m_y_winclean_01`, `s_m_y_xmech_01`, `s_m_y_xmech_02`,
    },
    Locations = {}
}

Config.ATMLocations = {}

Config.Animations = {
    -- Animation for skimming (handshake/hug style - looks like friendly interaction)
    Skimming = {
        dict = 'mp_ped_interaction', 
        anim = 'handshake_guy_a', -- Player's handshake animation
        flag = 48,
        -- Target (NPC) animation - they'll play the matching handshake
        targetDict = 'mp_ped_interaction',
        targetAnim = 'handshake_guy_b', -- NPC's side of the handshake
    },
    Injecting = {dict = 'anim@amb@clubhouse@tutorial@bkr_tut_ig3@', anim = 'machinic_loop_mechandplayer', flag = 1},
}

Config.Notifications = {
    SkimSuccess = 'You successfully skimmed a credit card!',
    SkimFailed = 'Skimming failed! The target noticed something.',
    SkimNoItem = 'You need a card skimmer to do this!',
    InjectSuccess = 'Card injected successfully! You received black money.',
    InjectFailed = 'Card injection failed! The ATM detected the fraud.',
    InjectNoCard = 'You need a credit card to inject!',
    InjectNoReader = 'You need a card reader to inject cards!',
    Cooldown = 'You need to wait before doing this again!',
    TooFar = 'You are too far away!',
    NoTarget = 'No valid target found!',
    ShopNotEnoughMoney = 'You don\'t have enough money!',
    ShopPurchaseSuccess = 'Purchase successful!',
    ShopPurchaseFailed = 'Purchase failed!',
    ShopItemOutOfStock = 'Item is out of stock!',
}
