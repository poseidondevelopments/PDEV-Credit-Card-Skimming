-- ============================================
-- POSEIDON DEVELOPMENT - Credit Card Skimming Items
-- Copyright (c) 2025 Poseidon Developments - All Rights Reserved
-- ============================================
-- Add these to your qb-core/shared/items.lua or use your item system
-- For ox_inventory, add these to your items database or ox_inventory/data/items.lua
-- ============================================

--[[
    ['card_skimmer'] = {
        name = 'card_skimmer',
        label = 'Card Skimmer',
        weight = 200,
        type = 'item',
        image = 'card_skimmer.png',
        unique = false,
        useable = false,
        shouldClose = true,
        combinable = nil,
        description = 'A sophisticated device used to skim credit card information from unsuspecting victims. Handle with care.',
        -- For ox_inventory: decay = 0 (no decay)
    },
    
    ['credit_card'] = {
        name = 'credit_card',
        label = 'Credit Card',
        weight = 10,
        type = 'item',
        image = 'credit_card.png',
        unique = true,
        useable = false,
        shouldClose = true,
        combinable = nil,
        description = 'A skimmed credit card containing encrypted financial data. Ready for injection into an ATM. Cards expire after 48 hours.',
        -- For ox_inventory: decay = 172800 (48 hours in seconds)
        -- Cards have quality tiers: Bronze, Silver, Gold, Platinum, Black
    },
    
    ['card_reader'] = {
        name = 'card_reader',
        label = 'Card Reader',
        weight = 300,
        type = 'item',
        image = 'card_reader.png',
        unique = false,
        useable = false,
        shouldClose = true,
        combinable = nil,
        description = 'A specialized device used to read and inject credit card data into ATMs. Essential for converting cards to cash.',
        -- For ox_inventory: decay = 0 (no decay)
    },
    
]]

-- ============================================
-- Installation Instructions:
-- ============================================
-- 1. For QBCore: Copy the items above to your qb-core/shared/items.lua file
-- 2. For ox_inventory: Add these to your items database or ox_inventory/data/items.lua
-- 3. Add corresponding images to your inventory system:
--    - card_skimmer.png
--    - credit_card.png
--    - card_reader.png
-- 4. Adjust weight, images, and descriptions as needed for your server
-- 5. Restart your server after adding items
-- ============================================

-- Item Images Suggestions:
-- You can find free credit card/item images online or create your own
-- Recommended size: 512x512 pixels
-- Format: PNG with transparency

