# Installation Guide - Credit Card Skimming Script

## Quick Start

1. **Download & Install**
   - Place the script folder in your `resources` directory
   - Rename it to `cc-card-skimming` (or your preferred name)

2. **Add Items**
   - Open `items.lua` in this script folder
   - Copy all 4 items to your `qb-core/shared/items.lua` file
   - Or if using ox_inventory, add to your items database/ox_inventory/data/items.lua

3. **Add Item Images**
   - Create or download images for:
     - `card_skimmer.png`
     - `credit_card.png`
     - `card_reader.png`
   - Add them to your inventory image folder

4. **Configure**
   - Edit `config.lua` to adjust settings
   - Set your dispatch system (or leave as 'auto' for auto-detection)

5. **Start Server**
   - Add `ensure cc-card-skimming` to your `server.cfg`
   - Restart your server

## Detailed Steps

### Step 1: Framework Setup

Ensure you have:
- ✅ QBCore Framework installed and running
- ✅ ox_lib installed (latest version)
- ✅ ox_target installed
- ✅ ox_inventory OR QBCore inventory system

### Step 2: Dispatch System (Optional)

The script supports multiple dispatch systems:
- **rcore_dispatch** - Most popular
- **lb-phone** - With dispatch features
- **wasabi_dispatch** - Alternative dispatch
- **cd_dispatch** - Another option

The script will auto-detect which one you're using, or you can set it manually in `config.lua`:

```lua
Config.Dispatch.System = 'rcore' -- or 'lb', 'wasabi', 'cd', 'auto', 'none'
```

### Step 3: Item Configuration

#### For QBCore Inventory:

Add these items to `qb-core/shared/items.lua`:

```lua
['card_skimmer'] = {
    name = 'card_skimmer',
    label = 'Card Skimmer',
    weight = 200,
    type = 'item',
    image = 'card_skimmer.png',
    unique = false,
    useable = false,
    shouldClose = true,
    combinable = nil,
    description = 'A device used to skim credit card information.'
},
-- ... (see items.lua for all items)
```

#### For ox_inventory:

Add items to your items database or `ox_inventory/data/items.lua`:

```lua
{
    name = 'card_skimmer',
    label = 'Card Skimmer',
    weight = 200,
    stack = true,
    close = true,
    description = 'A device used to skim credit card information.'
},
-- ... (see items.lua for all items)
```

### Step 4: Item Images

You need to add images for the items. Recommended:
- Size: 512x512 pixels
- Format: PNG with transparency
- Location: Your inventory's image folder

You can:
- Create your own images
- Use free stock images
- Use placeholder images for testing

### Step 5: Configuration

Edit `config.lua` to customize:

**Skimming Settings:**
```lua
Config.Skimming = {
    Duration = 5000,        -- How long skimming takes (ms)
    SuccessChance = 85,     -- Success rate (0-100)
    AlertChance = 25,       -- Police alert chance (0-100)
    Cooldown = 30000,       -- Cooldown between skims (ms)
}
```

**ATM Settings:**
```lua
Config.ATM = {
    Duration = 10000,       -- How long injection takes (ms)
    SuccessChance = 75,     -- Success rate (0-100)
    MinAmount = 500,        -- Minimum black money
    MaxAmount = 5000,       -- Maximum black money
    Cooldown = 60000,       -- Cooldown between injections (ms)
}
```

### Step 6: Testing

1. Start your server
2. Join the game
3. Use admin command: `/ccskim_give [your_id] skimmer 1`
4. Test skimming on NPCs
5. Test ATM injection

## Troubleshooting

### Script Not Working?

1. **Check Console**
   - Look for errors in F8 console
   - Check server console for errors

2. **Verify Dependencies**
   - Ensure ox_lib is installed
   - Ensure ox_target is installed
   - Ensure ox_inventory is installed (if using)

3. **Check Items**
   - Verify items are added to items.lua
   - Check item names match config.lua
   - Ensure item images exist

4. **Check Permissions**
   - Ensure script has proper permissions
   - Check resource is started: `ensure cc-card-skimming`

### Common Issues

**"No valid target found"**
- Make sure you're close enough (within 2 meters)
- Try targeting NPCs instead of players
- Check that you have a card_skimmer in inventory

**"You need a card skimmer"**
- Item not added to items.lua
- Item name mismatch in config.lua
- Inventory system issue

**Dispatch not working**
- Check dispatch system is installed
- Verify system name in config.lua
- Check dispatch resource is started

**Black money not received**
- Check black_money item exists
- Verify amount settings in config.lua
- Check server console for errors

## Support

If you encounter issues:
1. Check server console for errors
2. Check F8 client console
3. Verify all dependencies are installed
4. Ensure items are properly configured
5. Check config.lua settings

## Updates

To update the script:
1. Backup your config.lua (if customized)
2. Replace script files
3. Restore your config.lua
4. Restart server

