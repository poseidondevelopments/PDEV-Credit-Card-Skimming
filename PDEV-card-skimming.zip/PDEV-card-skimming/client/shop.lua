-- ============================================
-- POSEIDON DEVELOPMENT - Shop System
-- Copyright (c) 2025 Poseidon Developments - All Rights Reserved
-- ============================================

local ShopPeds, ShopBlips = {}, {}
local Framework, FrameworkType = nil, nil

CreateThread(function()
    Wait(1000)
    if GetResourceState('qbox_core') == 'started' then
        Framework, FrameworkType = exports.qbox_core:GetCoreObject(), 'qbox'
    elseif GetResourceState('qb-core') == 'started' then
        Framework, FrameworkType = exports['qb-core']:GetCoreObject(), 'qb'
    else
        Framework, FrameworkType = exports['qb-core']:GetCoreObject(), 'qb'
    end
end)

local function GetPlayerMoney()
    if not Framework then return 0, 0, 0 end
    local PlayerData = FrameworkType == 'qbox' and Framework:GetPlayerData() or Framework.Functions.GetPlayerData()
    if not PlayerData then return 0, 0, 0 end
    local money = PlayerData.money or {}
    local cash = money.cash or 0
    local bank = money.bank or 0
    local blackMoney = money.black_money or 0
    
    -- Check black_money as an item if using ox_inventory
    if exports.ox_inventory then
        local blackMoneyItem = exports.ox_inventory:Search('count', Config.BlackMoney.ItemName)
        if blackMoneyItem and blackMoneyItem > 0 then
            blackMoney = blackMoneyItem
        end
    end
    
    return cash, bank, blackMoney
end

local function SpawnShopPed(location, index)
    if not Config.Shop.Enabled then return end
    local model = location.pedModel
    RequestModel(model)
    while not HasModelLoaded(model) do Wait(10) end
    local ped = CreatePed(4, model, location.coords.x, location.coords.y, location.coords.z - 1.0, location.pedHeading, false, true)
    SetEntityAsMissionEntity(ped, true, true)
    SetPedFleeAttributes(ped, 0, false)
    SetPedCombatAttributes(ped, 46, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
    SetEntityInvincible(ped, true)
    FreezeEntityPosition(ped, true)
    if location.pedScenario then TaskStartScenarioInPlace(ped, location.pedScenario, 0, true) end
    ShopPeds[index] = ped
    if location.blip and location.blip.enabled then
        local blip = AddBlipForCoord(location.coords.x, location.coords.y, location.coords.z)
        SetBlipSprite(blip, location.blip.sprite)
        SetBlipColour(blip, location.blip.color)
        SetBlipScale(blip, location.blip.scale)
        SetBlipAsShortRange(blip, true)
        BeginTextCommandSetBlipName('STRING')
        AddTextComponentString(location.blip.label)
        EndTextCommandSetBlipName(blip)
        ShopBlips[index] = blip
    end
    if exports.ox_target then
        exports.ox_target:addLocalEntity(ped, {{
            name = 'poseidon_shop',
            icon = 'fas fa-shopping-cart',
            label = 'Browse Illegal Equipment',
            canInteract = function(entity, distance) return distance < 2.5 end,
            onSelect = function(data) OpenShopMenu(index) end
        }})
    end
end

function OpenShopMenu(shopIndex)
    if not Config.Shop.Enabled or not Config.Shop.Locations[shopIndex] then return end
    local cash, bank, blackMoney = GetPlayerMoney()
    local shopItems = {}
    for i, item in ipairs(Config.Shop.Items) do
        local stockText = Config.Shop.Settings.ShowStock and (item.stock == -1 and ' (Unlimited)' or ' (Stock: ' .. item.stock .. ')') or ''
        local priceText = Config.Shop.Settings.UseCash and '$' .. item.price .. ' Cash' or
                         Config.Shop.Settings.UseBank and '$' .. item.price .. ' Bank' or
                         Config.Shop.Settings.UseBlackMoney and '$' .. item.price .. ' Black Money' or ''
        table.insert(shopItems, {
            title = item.label .. stockText,
            description = item.description .. '\nPrice: ' .. priceText,
            icon = 'shopping-cart',
            onSelect = function() BuyItem(shopIndex, i, item) end,
            metadata = {
                {label = 'Price', value = priceText},
                {label = 'Stock', value = item.stock == -1 and 'Unlimited' or tostring(item.stock)},
                {label = 'Category', value = item.category or 'General'}
            }
        })
    end
    lib.registerContext({id = 'poseidon_shop_' .. shopIndex, title = 'POSEIDON CARD SKIM - Illegal Equipment', options = shopItems})
    lib.showContext('poseidon_shop_' .. shopIndex)
end

function BuyItem(shopIndex, itemIndex, itemData)
    if not Config.Shop.Enabled then return end
    if itemData.stock ~= -1 and itemData.stock <= 0 then
        lib.notify({title = 'POSEIDON CARD SKIM', description = Config.Notifications.ShopItemOutOfStock, type = 'error'})
        return
    end
    local cash, bank, blackMoney = GetPlayerMoney()
    local hasEnough, moneyType = false, ''
    if Config.Shop.Settings.UseCash and cash >= itemData.price then hasEnough, moneyType = true, 'cash'
    elseif Config.Shop.Settings.UseBank and bank >= itemData.price then hasEnough, moneyType = true, 'bank'
    elseif Config.Shop.Settings.UseBlackMoney and blackMoney >= itemData.price then hasEnough, moneyType = true, 'black_money' end
    if not hasEnough then
        lib.notify({title = 'POSEIDON CARD SKIM', description = Config.Notifications.ShopNotEnoughMoney, type = 'error'})
        return
    end
    local input = lib.inputDialog('POSEIDON CARD SKIM - Purchase', {{
        type = 'number', label = 'Quantity', description = 'How many would you like to buy?',
        required = true, min = 1, max = Config.Shop.Settings.AllowMultiple and 10 or 1, default = 1
    }})
    if not input or not input[1] then return end
    local quantity = math.floor(input[1])
    if quantity < 1 then return end
    local totalPrice = itemData.price * quantity
    local hasEnoughTotal = false
    if Config.Shop.Settings.UseCash and cash >= totalPrice then hasEnoughTotal, moneyType = true, 'cash'
    elseif Config.Shop.Settings.UseBank and bank >= totalPrice then hasEnoughTotal, moneyType = true, 'bank'
    elseif Config.Shop.Settings.UseBlackMoney and blackMoney >= totalPrice then hasEnoughTotal, moneyType = true, 'black_money' end
    if not hasEnoughTotal then
        lib.notify({title = 'POSEIDON CARD SKIM', description = Config.Notifications.ShopNotEnoughMoney, type = 'error'})
        return
    end
    if itemData.stock ~= -1 and itemData.stock < quantity then
        lib.notify({title = 'POSEIDON CARD SKIM', description = 'Not enough stock available!', type = 'error'})
        return
    end
    if not Framework then return end
    local callback = FrameworkType == 'qbox' and Framework.TriggerCallback or Framework.Functions.TriggerCallback
    callback('poseidon:shop:purchase', function(success, message)
        if success then
            if Config.Shop.Settings.Animation.enabled then
                local playerPed = PlayerPedId()
                RequestAnimDict(Config.Shop.Settings.Animation.dict)
                while not HasAnimDictLoaded(Config.Shop.Settings.Animation.dict) do Wait(10) end
                TaskPlayAnim(playerPed, Config.Shop.Settings.Animation.dict, Config.Shop.Settings.Animation.anim, 8.0, -8.0, Config.Shop.Settings.Animation.duration, 0, 0, false, false, false)
                Wait(Config.Shop.Settings.Animation.duration)
                ClearPedTasksImmediately(playerPed)
            end
            lib.notify({title = 'POSEIDON CARD SKIM', description = Config.Notifications.ShopPurchaseSuccess, type = 'success'})
        else
            lib.notify({title = 'POSEIDON CARD SKIM', description = message or Config.Notifications.ShopPurchaseFailed, type = 'error'})
        end
    end, shopIndex, itemIndex, quantity, moneyType)
end

CreateThread(function()
    if not Config.Shop.Enabled then return end
    Wait(2000)
    for i, location in ipairs(Config.Shop.Locations) do SpawnShopPed(location, i) end
end)

AddEventHandler('onResourceStop', function(resourceName)
    if GetCurrentResourceName() == resourceName then
        for _, ped in pairs(ShopPeds) do if DoesEntityExist(ped) then DeleteEntity(ped) end end
        for _, blip in pairs(ShopBlips) do if DoesBlipExist(blip) then RemoveBlip(blip) end end
    end
end)
