-- ============================================
-- POSEIDON DEVELOPMENT - Main Client Script
-- Copyright (c) 2025 Poseidon Developments - All Rights Reserved
-- ============================================

-- Framework Detection
local Framework = nil
local FrameworkType = nil

-- Detect framework
CreateThread(function()
    Wait(1000) -- Wait for frameworks to load
    if GetResourceState('qbox_core') == 'started' then
        Framework = exports.qbox_core:GetCoreObject()
        FrameworkType = 'qbox'
        if Config.Debug then
            print('[CCSkim] Client: Detected QBox framework')
        end
    elseif GetResourceState('qb-core') == 'started' then
        Framework = exports['qb-core']:GetCoreObject()
        FrameworkType = 'qb'
        if Config.Debug then
            print('[CCSkim] Client: Detected QBCore framework')
        end
    else
        Framework = exports['qb-core']:GetCoreObject()
        FrameworkType = 'qb'
    end
end)

local PlayerData = {}
local isSkimming = false
local isInjecting = false
local lastSkimTime = 0
local lastInjectTime = 0
local nearbyATMs = {}
local skimmedNPCs = {} -- Track NPCs that have been skimmed (entity handle -> true)

-- Performance optimization caches
local cachedTargetModels = {}
local cachedATMModels = {
    `prop_atm_01`,
    `prop_atm_02`,
    `prop_atm_03`,
    `prop_fleeca_atm`,
}
local lastNPCCheck = 0
local cachedNPCs = {}
local NPC_CACHE_TIME = 2000 -- Cache NPCs for 2 seconds

-- Initialize
local function GetPlayerData()
    if not Framework then return {} end
    if FrameworkType == 'qbox' then
        return Framework:GetPlayerData()
    else
        return Framework.Functions.GetPlayerData()
    end
end

RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    PlayerData = GetPlayerData()
end)

RegisterNetEvent('QBox:Client:OnPlayerLoaded', function()
    PlayerData = GetPlayerData()
end)

RegisterNetEvent('QBCore:Client:OnPlayerUnload', function()
    PlayerData = {}
end)

RegisterNetEvent('QBox:Client:OnPlayerUnload', function()
    PlayerData = {}
end)

RegisterNetEvent('QBCore:Player:SetPlayerData', function(val)
    PlayerData = val
end)

RegisterNetEvent('QBox:Player:SetPlayerData', function(val)
    PlayerData = val
end)

-- Helper Functions
local function GetClosestPlayer()
    local closestPlayer = -1
    local closestDistance = Config.Skimming.MinDistance
    local playerPed = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)
    local minDistSq = Config.Skimming.MinDistance * Config.Skimming.MinDistance
    local players = GetActivePlayers()
    
    for i = 1, #players do
        local player = players[i]
        local targetPed = GetPlayerPed(player)
        if targetPed ~= playerPed and DoesEntityExist(targetPed) then
            local targetCoords = GetEntityCoords(targetPed)
            local dx = playerCoords.x - targetCoords.x
            local dy = playerCoords.y - targetCoords.y
            local dz = playerCoords.z - targetCoords.z
            local distSq = dx*dx + dy*dy + dz*dz
            
            if distSq < minDistSq then
                local distance = math.sqrt(distSq)
                if distance < closestDistance then
                    closestDistance = distance
                    closestPlayer = GetPlayerServerId(player)
                end
            end
        end
    end
    
    return closestPlayer, closestDistance
end

-- Build target models cache once
local function BuildTargetModelsCache()
    if #cachedTargetModels > 0 then return end
    for _, model in ipairs(Config.SkimTargets.Models) do
        cachedTargetModels[model] = true
    end
end

-- Initialize cache
CreateThread(function()
    BuildTargetModelsCache()
end)

local function GetClosestNPC()
    local currentTime = GetGameTimer()
    local playerPed = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)
    local closestNPC = nil
    local closestDistance = Config.Skimming.MinDistance
    
    -- Use cached NPCs if available and recent
    if currentTime - lastNPCCheck < NPC_CACHE_TIME and #cachedNPCs > 0 then
        for _, ped in ipairs(cachedNPCs) do
            if DoesEntityExist(ped) and not IsPedDeadOrDying(ped, true) then
                local pedCoords = GetEntityCoords(ped)
                local distance = #(playerCoords - pedCoords)
                if distance < closestDistance then
                    closestDistance = distance
                    closestNPC = ped
                end
            end
        end
        if closestNPC then
            return closestNPC, closestDistance
        end
    end
    
    -- Refresh cache and find NPC
    cachedNPCs = {}
    local peds = GetGamePool('CPed')
    local minDistSq = Config.Skimming.MinDistance * Config.Skimming.MinDistance -- Use squared distance for performance
    
    for i = 1, #peds do
        local ped = peds[i]
        if ped ~= playerPed and DoesEntityExist(ped) and not IsPedAPlayer(ped) and not IsPedDeadOrDying(ped, true) then
            local pedModel = GetEntityModel(ped)
            
            -- Fast model check using hash table
            if cachedTargetModels[pedModel] then
                local pedCoords = GetEntityCoords(ped)
                local dx = playerCoords.x - pedCoords.x
                local dy = playerCoords.y - pedCoords.y
                local dz = playerCoords.z - pedCoords.z
                local distSq = dx*dx + dy*dy + dz*dz
                
                if distSq < minDistSq then
                    local distance = math.sqrt(distSq)
                    if distance < closestDistance then
                        closestDistance = distance
                        closestNPC = ped
                    end
                    cachedNPCs[#cachedNPCs + 1] = ped
                end
            end
        end
    end
    
    lastNPCCheck = currentTime
    return closestNPC, closestDistance
end

local lastATMCheck = 0
local cachedATM = nil
local ATM_CACHE_TIME = 1000 -- Cache ATM for 1 second

local function FindNearbyATM()
    local currentTime = GetGameTimer()
    local playerPed = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)
    local closestATM = nil
    local closestDistance = Config.ATM.MinDistance
    
    -- Use cached ATM if available and recent
    if currentTime - lastATMCheck < ATM_CACHE_TIME and cachedATM then
        if DoesEntityExist(cachedATM.entity) then
            local atmCoords = GetEntityCoords(cachedATM.entity)
            local distance = #(playerCoords - atmCoords)
            if distance < Config.ATM.MinDistance then
                return cachedATM, distance
            end
        end
    end
    
    -- Check custom ATM locations first (usually faster)
    for i = 1, #Config.ATMLocations do
        local location = Config.ATMLocations[i]
        local dx = playerCoords.x - location.coords.x
        local dy = playerCoords.y - location.coords.y
        local dz = playerCoords.z - location.coords.z
        local distance = math.sqrt(dx*dx + dy*dy + dz*dz)
        
        if distance < closestDistance then
            closestDistance = distance
            closestATM = location
        end
    end
    
    -- Auto-detect ATMs (only if no custom location found)
    if not closestATM then
        for i = 1, #cachedATMModels do
            local model = cachedATMModels[i]
            local atm = GetClosestObjectOfType(playerCoords.x, playerCoords.y, playerCoords.z, Config.ATM.MinDistance, model, false, false, false)
            if atm ~= 0 then
                local atmCoords = GetEntityCoords(atm)
                local dx = playerCoords.x - atmCoords.x
                local dy = playerCoords.y - atmCoords.y
                local dz = playerCoords.z - atmCoords.z
                local distance = math.sqrt(dx*dx + dy*dy + dz*dz)
                
                if distance < closestDistance then
                    closestDistance = distance
                    closestATM = {coords = atmCoords, entity = atm}
                    cachedATM = closestATM
                    lastATMCheck = currentTime
                end
            end
        end
    end
    
    return closestATM, closestDistance
end

local function HasItem(item)
    if exports.ox_inventory then
        local count = exports.ox_inventory:Search('count', item)
        if Config.Debug then
            print(string.format('[CCSkim] HasItem check - item: %s, count: %s', item, tostring(count)))
        end
        return count and count > 0
    else
        -- Fallback to framework
        if not Framework then return false end
        if FrameworkType == 'qbox' then
            return Framework:HasItem(item)
        else
            return Framework.Functions.HasItem(item)
        end
    end
end

local function PlayAnimation(dict, anim, flag, duration, targetEntity)
    local playerPed = PlayerPedId()
    RequestAnimDict(dict)
    while not HasAnimDictLoaded(dict) do
        Wait(100)
    end
    TaskPlayAnim(playerPed, dict, anim, 8.0, -8.0, duration or -1, flag or 1, 0, false, false, false)
    
    -- If target entity provided and has target animation, play it on the target too
    if targetEntity and DoesEntityExist(targetEntity) and Config.Animations.Skimming.targetDict and Config.Animations.Skimming.targetAnim then
        RequestAnimDict(Config.Animations.Skimming.targetDict)
        while not HasAnimDictLoaded(Config.Animations.Skimming.targetDict) do
            Wait(10)
        end
        TaskPlayAnim(targetEntity, Config.Animations.Skimming.targetDict, Config.Animations.Skimming.targetAnim, 8.0, -8.0, duration or -1, flag or 1, 0, false, false, false)
    end
end

local function StopAnimation(targetEntity)
    local playerPed = PlayerPedId()
    ClearPedTasksImmediately(playerPed)
    
    -- Also stop animation on target if provided and restore NPC behavior
    if targetEntity and DoesEntityExist(targetEntity) then
        ClearPedTasksImmediately(targetEntity)
        
        -- Restore NPC's normal behavior if it's an NPC
        if not IsPedAPlayer(targetEntity) then
            SetBlockingOfNonTemporaryEvents(targetEntity, false)
        end
    end
end

-- Dispatch System Compatibility
local function SendDispatchAlert(coords, message, sprite, color)
    if Config.Dispatch.System == 'none' then return end
    
    local system = Config.Dispatch.System
    
    -- Auto-detect dispatch system
    if system == 'auto' then
        if GetResourceState('rcore_dispatch') == 'started' then
            system = 'rcore'
        elseif GetResourceState('lb-phone') == 'started' then
            system = 'lb'
        elseif GetResourceState('wasabi_dispatch') == 'started' then
            system = 'wasabi'
        elseif GetResourceState('cd_dispatch') == 'started' then
            system = 'cd'
        else
            system = 'none'
        end
    end
    
    if system == 'rcore' then
        exports['rcore_dispatch']:CustomAlert({
            coords = coords,
            message = message or 'Suspicious Activity',
            sprite = sprite or 431,
            color = color or 1,
            scale = 1.0,
            length = Config.Dispatch.AlertDuration,
        })
    elseif system == 'lb' then
        exports['lb-phone']:SendDispatchAlert({
            coords = coords,
            message = message or 'Suspicious Activity',
            sprite = sprite or 431,
            color = color or 1,
            scale = 1.0,
            length = Config.Dispatch.AlertDuration,
        })
    elseif system == 'wasabi' then
        exports['wasabi_dispatch']:CustomAlert({
            coords = coords,
            message = message or 'Suspicious Activity',
            sprite = sprite or 431,
            color = color or 1,
            scale = 1.0,
            length = Config.Dispatch.AlertDuration,
        })
    elseif system == 'cd' then
        exports['cd_dispatch']:AddNotification({
            title = 'Suspicious Activity',
            message = message or 'Reported suspicious activity',
            coords = coords,
            sprite = sprite or 431,
            color = color or 1,
        })
    end
end

-- Skimming Function
local function SkimCard(targetEntity)
    if isSkimming then return end
    if GetGameTimer() - lastSkimTime < Config.Skimming.Cooldown then
        lib.notify({
            title = 'Error',
            description = Config.Notifications.Cooldown,
            type = 'error'
        })
        return
    end
    
    if not HasItem(Config.Items.Skimmer) then
        lib.notify({
            title = 'Error',
            description = Config.Notifications.SkimNoItem,
            type = 'error'
        })
        return
    end
    
    -- Use provided entity if available, otherwise find closest target
    local target = nil
    local targetType = nil
    local targetCoords = nil
    local targetPed = nil -- Will be set later for animation
    
    if targetEntity and DoesEntityExist(targetEntity) then
        -- Use the provided entity (from ox_target)
        print(string.format('[CCSkim] Using provided entity: %s', tostring(targetEntity)))
        if IsPedAPlayer(targetEntity) then
            -- It's a player - get server ID
            local targetServerId = NetworkGetPlayerIndexFromPed(targetEntity)
            if targetServerId ~= -1 then
                target = GetPlayerServerId(targetServerId)
                targetType = 'player'
                targetCoords = GetEntityCoords(targetEntity)
                print(string.format('[CCSkim] Target is player, server ID: %s', tostring(target)))
            end
        else
            -- It's an NPC - server doesn't need the entity, just the type
            target = 0  -- Server doesn't validate NPCs, so any value works
            targetType = 'npc'
            targetCoords = GetEntityCoords(targetEntity)
            print(string.format('[CCSkim] Target is NPC, entity: %s, using target: 0', tostring(targetEntity)))
        end
    end
    
    -- Fallback: Try to find closest target if no entity provided
    if not target or not targetCoords then
        print('[CCSkim] No entity provided, searching for closest target...')
        local targetPlayer, playerDistance = GetClosestPlayer()
        local targetNPC, npcDistance = GetClosestNPC()
        
        if targetPlayer ~= -1 and playerDistance < Config.Skimming.MinDistance then
            target = targetPlayer
            targetType = 'player'
            local targetPed = GetPlayerPed(GetPlayerFromServerId(targetPlayer))
            targetCoords = GetEntityCoords(targetPed)
        elseif targetNPC and npcDistance < Config.Skimming.MinDistance then
            target = targetNPC
            targetType = 'npc'
            targetCoords = GetEntityCoords(targetNPC)
        end
    end
    
    if not target or not targetCoords then
        lib.notify({
            title = 'Error',
            description = Config.Notifications.NoTarget,
            type = 'error'
        })
        return
    end
    
    print(string.format('[CCSkim] Final target: %s, type: %s', tostring(target), targetType))
    
    -- Optimized distance check
    local playerCoords = GetEntityCoords(PlayerPedId())
    local dx = playerCoords.x - targetCoords.x
    local dy = playerCoords.y - targetCoords.y
    local dz = playerCoords.z - targetCoords.z
    local distSq = dx*dx + dy*dy + dz*dz
    local minDistSq = Config.Skimming.MinDistance * Config.Skimming.MinDistance
    
    if distSq > minDistSq then
        lib.notify({
            title = 'Error',
            description = Config.Notifications.TooFar,
            type = 'error'
        })
        return
    end
    
    isSkimming = true
    lastSkimTime = GetGameTimer()
    
    -- Get target entity for animation (targetPed already declared at function start)
    if targetType == 'player' then
        targetPed = GetPlayerPed(GetPlayerFromServerId(target))
    elseif targetType == 'npc' and targetEntity then
        targetPed = targetEntity
    end
    
    -- Make NPC walk to player, stop, face them, then shake hands
    if targetPed and DoesEntityExist(targetPed) and not IsPedAPlayer(targetPed) then
        local playerPed = PlayerPedId()
        local playerCoords = GetEntityCoords(playerPed)
        
        -- Block NPC from doing other tasks
        SetBlockingOfNonTemporaryEvents(targetPed, true)
        
        -- Make NPC walk to player (stop 1.5 meters away for handshake)
        TaskGoToEntity(targetPed, playerPed, -1, 1.5, 2.0, 1073741824, 0)
        
        -- Wait for NPC to reach player (max 5 seconds)
        local waitTime = 0
        while waitTime < 5000 do
            Wait(100)
            waitTime = waitTime + 100
            local npcCoords = GetEntityCoords(targetPed)
            local distance = #(playerCoords - npcCoords)
            if distance <= 2.0 then
                break -- NPC reached player
            end
        end
        
        -- Stop NPC from moving
        ClearPedTasksImmediately(targetPed)
        TaskStandStill(targetPed, Config.Skimming.Duration + 2000)
        
        -- Make NPC face the player
        TaskTurnPedToFaceEntity(targetPed, playerPed, 1000)
        Wait(500) -- Give NPC time to turn
        
        -- Make player face NPC too
        TaskTurnPedToFaceEntity(playerPed, targetPed, 1000)
        Wait(300)
    end
    
    -- Play animation on both player and target (handshake/hug)
    PlayAnimation(Config.Animations.Skimming.dict, Config.Animations.Skimming.anim, Config.Animations.Skimming.flag, Config.Skimming.Duration, targetPed)
    
    -- Progress bar
    if lib.progressBar({
        duration = Config.Skimming.Duration,
        label = 'Skimming credit card...',
        useWhileDead = false,
        canCancel = true,
        disable = {
            car = true,
            move = true,
            combat = true,
        },
        anim = {
            dict = Config.Animations.Skimming.dict,
            clip = Config.Animations.Skimming.anim,
        },
    }) then
        -- Check success chance
        local success = math.random(100) <= Config.Skimming.SuccessChance
        
        if success then
            -- Always alert police when skimming starts (before result)
            if Config.Dispatch.AlwaysAlertOnSkim then
                SendDispatchAlert(targetCoords, 'Suspicious activity reported - possible credit card fraud', 431, 1)
            end
            
            -- Trigger server event
            if not Framework then
                lib.notify({
                    title = 'Error',
                    description = 'Framework not loaded',
                    type = 'error'
                })
                return
            end
            
            local function TriggerCallback(name, cb, ...)
                if FrameworkType == 'qbox' then
                    Framework:TriggerCallback(name, cb, ...)
                else
                    Framework.Functions.TriggerCallback(name, cb, ...)
                end
            end
            
            TriggerCallback('ccskim:server:skimCard', function(result, limitMessage)
                if result then
                    -- Mark NPC as skimmed if it was an NPC
                    if targetType == 'npc' and targetEntity and DoesEntityExist(targetEntity) then
                        skimmedNPCs[targetEntity] = true
                        -- Remove the target option for this NPC
                        pcall(function()
                            exports.ox_target:removeLocalEntity(targetEntity, 'ccskim:skim:npc:' .. targetEntity)
                        end)
                        if Config.Debug then
                            print(string.format('[CCSkim] Marked NPC %s as skimmed and removed target option', tostring(targetEntity)))
                        end
                    end
                    
                    -- Get card quality info if available
                    local qualityText = ''
                    if Config.CardQuality.Enabled then
                        Wait(300) -- Wait for item to be added to inventory
                        if exports.ox_inventory then
                            local inventory = exports.ox_inventory:GetInventory()
                            if inventory then
                                for _, item in pairs(inventory) do
                                    if item and item.name == Config.Items.CreditCard and item.metadata and item.metadata.qualityLabel then
                                        qualityText = ' (' .. item.metadata.qualityLabel .. ')'
                                        break
                                    end
                                end
                            end
                        end
                    end
                    lib.notify({
                        title = 'Success',
                        description = Config.Notifications.SkimSuccess .. qualityText,
                        type = 'success'
                    })
                    
                    -- Alert on success if configured
                    if Config.Dispatch.AlertOnSuccess and not Config.Dispatch.AlwaysAlertOnSkim then
                        if math.random(100) <= Config.Skimming.AlertChance then
                            SendDispatchAlert(targetCoords, 'Credit card fraud detected', 431, 1)
                        end
                    end
                else
                    local errorMsg = limitMessage or 'Failed to process card'
                    lib.notify({
                        title = 'Error',
                        description = errorMsg,
                        type = 'error'
                    })
                    
                    -- Alert on failure if configured
                    if Config.Dispatch.AlertOnFailure and not Config.Dispatch.AlwaysAlertOnSkim then
                        SendDispatchAlert(targetCoords, 'Suspicious activity reported - possible credit card fraud', 431, 1)
                    end
                end
            end, targetType, target)
        else
            lib.notify({
                title = 'Failed',
                description = Config.Notifications.SkimFailed,
                type = 'error'
            })
            
            -- Alert on failure if configured
            if Config.Dispatch.AlertOnFailure and not Config.Dispatch.AlwaysAlertOnSkim then
                if math.random(100) <= Config.Skimming.AlertChance then
                    SendDispatchAlert(targetCoords, 'Suspicious activity reported - possible credit card fraud', 431, 1)
                end
            elseif Config.Dispatch.AlwaysAlertOnSkim then
                SendDispatchAlert(targetCoords, 'Suspicious activity reported - possible credit card fraud', 431, 1)
            end
        end
    else
        lib.notify({
            title = 'Cancelled',
            description = 'Skimming cancelled',
            type = 'inform'
        })
    end
    
    -- Stop animation on both player and target (targetPed already set above)
    StopAnimation(targetPed)
    isSkimming = false
end

-- ATM Injection Function
local function InjectCard()
    if isInjecting then return end
    if GetGameTimer() - lastInjectTime < Config.ATM.Cooldown then
        lib.notify({
            title = 'Error',
            description = Config.Notifications.Cooldown,
            type = 'error'
        })
        return
    end
    
    if not HasItem(Config.Items.CreditCard) then
        lib.notify({
            title = 'Error',
            description = Config.Notifications.InjectNoCard,
            type = 'error'
        })
        return
    end
    
    if not HasItem(Config.Items.CardReader) then
        lib.notify({
            title = 'Error',
            description = Config.Notifications.InjectNoReader,
            type = 'error'
        })
        return
    end
    
    local atm, distance = FindNearbyATM()
    
    if not atm then
        lib.notify({
            title = 'Error',
            description = 'No ATM found nearby',
            type = 'error'
        })
        return
    end
    
    if distance > Config.ATM.MinDistance then
        lib.notify({
            title = 'Error',
            description = Config.Notifications.TooFar,
            type = 'error'
        })
        return
    end
    
    isInjecting = true
    lastInjectTime = GetGameTimer()
    
    local atmCoords = atm.coords or atm
    
    -- Play animation
    PlayAnimation(Config.Animations.Injecting.dict, Config.Animations.Injecting.anim, Config.Animations.Injecting.flag, Config.ATM.Duration)
    
    -- Progress bar
    if lib.progressBar({
        duration = Config.ATM.Duration,
        label = 'Injecting card into ATM...',
        useWhileDead = false,
        canCancel = true,
        disable = {
            car = true,
            move = true,
            combat = true,
        },
        anim = {
            dict = Config.Animations.Injecting.dict,
            clip = Config.Animations.Injecting.anim,
        },
    }) then
        -- Success chance is now handled server-side based on card quality
        -- Client just triggers the callback
        local success = true -- Server will determine actual success
        
        if success then
            -- Trigger server event
            if not Framework then
                lib.notify({
                    title = 'Error',
                    description = 'Framework not loaded',
                    type = 'error'
                })
                return
            end
            
            local function TriggerCallback(name, cb, ...)
                if FrameworkType == 'qbox' then
                    Framework:TriggerCallback(name, cb, ...)
                else
                    Framework.Functions.TriggerCallback(name, cb, ...)
                end
            end
            
            TriggerCallback('ccskim:server:injectCard', function(result, amount, cardQuality, alertMultiplier)
                if result then
                    local qualityText = cardQuality and (' (' .. cardQuality .. ' Card)') or ''
                    lib.notify({
                        title = 'Success',
                        description = Config.Notifications.InjectSuccess .. ' ($' .. amount .. ')' .. qualityText,
                        type = 'success'
                    })
                    
                    -- Chance to alert police (modified by card quality)
                    local alertChance = Config.ATM.AlertChance
                    if alertMultiplier then
                        alertChance = math.floor(Config.ATM.AlertChance * alertMultiplier)
                    end
                    if math.random(100) <= math.min(alertChance, 100) then
                        SendDispatchAlert(atmCoords, 'ATM fraud detected - suspicious transaction', 431, 1)
                    end
                else
                    lib.notify({
                        title = 'Error',
                        description = amount and amount > 0 and 'Card injection failed!' or 'Failed to process injection',
                        type = 'error'
                    })
                end
            end)
        else
            lib.notify({
                title = 'Failed',
                description = Config.Notifications.InjectFailed,
                type = 'error'
            })
            
            -- Higher chance to alert police on failure
            if math.random(100) <= (Config.ATM.AlertChance * 2) then
                SendDispatchAlert(atmCoords, 'ATM fraud detected - suspicious transaction', 431, 1)
            end
        end
    else
        lib.notify({
            title = 'Cancelled',
            description = 'Injection cancelled',
            type = 'inform'
        })
    end
    
    StopAnimation()
    isInjecting = false
end

-- Ox Target Integration
CreateThread(function()
    -- Wait for ox_target to be ready
    local waitCount = 0
    while not exports.ox_target do
        Wait(100)
        waitCount = waitCount + 1
        if waitCount > 100 then -- 10 seconds timeout
            print('[CCSkim ERROR] ox_target not found after 10 seconds! Make sure ox_target resource is started.')
            return
        end
    end
    
    print('[CCSkim] ox_target loaded, registering target options...')
    
    -- Add target option for players (skimming)
    local success, err = pcall(function()
        print('[CCSkim] Registering addGlobalPlayer for players...')
        exports.ox_target:addGlobalPlayer({
        {
            name = 'ccskim:skim:player',
            icon = 'fas fa-credit-card',
            label = 'Skim Credit Card',
            canInteract = function(entity, distance, coords, name, bone)
                print('[CCSkim] ===== canInteract FUNCTION CALLED =====')
                print(string.format('[CCSkim] Entity: %s, Distance: %.2f', tostring(entity), distance))
                -- Check if player has the skimmer item
                local hasSkimmer = HasItem(Config.Items.Skimmer)
                local onCooldown = GetGameTimer() - lastSkimTime < Config.Skimming.Cooldown
                
                -- Always show debug output when third-eyeing
                print(string.format('[CCSkim] canInteract check - hasSkimmer: %s, distance: %.2f (min: %.2f), isSkimming: %s, onCooldown: %s', 
                    tostring(hasSkimmer), distance, Config.Skimming.MinDistance, tostring(isSkimming), tostring(onCooldown)))
                
                -- Must have skimmer
                if not hasSkimmer then 
                    print('[CCSkim] Cannot interact: Missing card_skimmer item!')
                    return false 
                end
                
                -- Must be close enough
                if distance >= Config.Skimming.MinDistance then 
                    print(string.format('[CCSkim] Cannot interact: Too far away! Distance: %.2f, Required: %.2f', distance, Config.Skimming.MinDistance))
                    return false 
                end
                
                -- Check if already skimming
                if isSkimming then 
                    print('[CCSkim] Cannot interact: Already skimming!')
                    return false 
                end
                
                -- Check cooldown
                if onCooldown then 
                    local remaining = math.ceil((Config.Skimming.Cooldown - (GetGameTimer() - lastSkimTime)) / 1000)
                    print(string.format('[CCSkim] Cannot interact: On cooldown! %d seconds remaining', remaining))
                    return false 
                end
                
                print('[CCSkim] canInteract: All checks passed!')
                return true
            end,
            onSelect = function(data)
                print('[CCSkim] Skim option selected!')
                print(string.format('[CCSkim] Selected entity: %s', tostring(data.entity)))
                SkimCard(data.entity)
            end
        }
    })
    end) -- Close pcall
    
    if not success then
        print(string.format('[CCSkim ERROR] Failed to register player target option: %s', tostring(err)))
    else
        print('[CCSkim] Successfully registered player target option (Skim Credit Card)')
    end
    
    -- Add target option for NPCs using addModel (addGlobalPlayer might not work for NPCs)
    local successNPC, errNPC = pcall(function()
        print('[CCSkim] Registering NPC target option using addModel...')
        -- Use common ped models for NPCs
        exports.ox_target:addModel({
            `mp_m_freemode_01`,
            `mp_f_freemode_01`,
        }, {
            {
                name = 'ccskim:skim:npc',
                icon = 'fas fa-credit-card',
                label = 'Skim Credit Card',
                canInteract = function(entity, distance, coords, name, bone)
                    print('[CCSkim] ===== NPC canInteract FUNCTION CALLED =====')
                    if not entity or not DoesEntityExist(entity) then return false end
                    if IsPedAPlayer(entity) then 
                        print('[CCSkim] Entity is a player, skipping')
                        return false 
                    end
                    
                    print(string.format('[CCSkim] Entity: %s, Distance: %.2f', tostring(entity), distance))
                    local hasSkimmer = HasItem(Config.Items.Skimmer)
                    local onCooldown = GetGameTimer() - lastSkimTime < Config.Skimming.Cooldown
                    
                    print(string.format('[CCSkim] NPC canInteract - hasSkimmer: %s, distance: %.2f (min: %.2f), isSkimming: %s, onCooldown: %s', 
                        tostring(hasSkimmer), distance, Config.Skimming.MinDistance, tostring(isSkimming), tostring(onCooldown)))
                    
                    if not hasSkimmer then 
                        print('[CCSkim] Cannot interact: Missing card_skimmer item!')
                        return false 
                    end
                    if distance >= Config.Skimming.MinDistance then 
                        print(string.format('[CCSkim] Cannot interact: Too far away! Distance: %.2f, Required: %.2f', distance, Config.Skimming.MinDistance))
                        return false 
                    end
                    if isSkimming then return false end
                    if onCooldown then return false end
                    
                    print('[CCSkim] NPC canInteract: All checks passed!')
                    return true
                end,
                onSelect = function(data)
                    print('[CCSkim] NPC Skim option selected!')
                    SkimCard()
                end
            }
        })
    end)
    
    if not successNPC then
        print(string.format('[CCSkim ERROR] Failed to register NPC target option: %s', tostring(errNPC)))
    else
        print('[CCSkim] Successfully registered NPC target option (Skim Credit Card)')
    end
    
    -- Add target option for ATMs (injection)
    local success2, err2 = pcall(function()
        exports.ox_target:addModel({
            `prop_atm_01`,
            `prop_atm_02`,
            `prop_atm_03`,
            `prop_fleeca_atm`,
        }, {
            {
                name = 'ccskim:inject',
                icon = 'fas fa-sd-card',
                label = 'Inject Credit Card',
                canInteract = function(entity, distance, coords, name, bone)
                    if isInjecting then return false end
                    if GetGameTimer() - lastInjectTime < Config.ATM.Cooldown then return false end
                    return HasItem(Config.Items.CreditCard) and HasItem(Config.Items.CardReader) and distance < Config.ATM.MinDistance
                end,
                onSelect = function(data)
                    print('[CCSkim] Inject option selected!')
                    InjectCard()
                end
            }
        })
    end)
    
    if not success2 then
        print(string.format('[CCSkim ERROR] Failed to register ATM target option: %s', tostring(err2)))
    else
        print('[CCSkim] Successfully registered ATM target option (Inject Credit Card)')
    end
    
    -- Also add to custom ATM locations if any
    for _, location in ipairs(Config.ATMLocations) do
        exports.ox_target:addSphereZone({
            coords = location.coords,
            radius = 2.0,
            debug = Config.Debug,
            options = {
                {
                    name = 'ccskim:inject',
                    icon = 'fas fa-sd-card',
                    label = 'Inject Credit Card',
                    canInteract = function(entity, distance, coords, name)
                        if isInjecting then return false end
                        if GetGameTimer() - lastInjectTime < Config.ATM.Cooldown then return false end
                        return HasItem(Config.Items.CreditCard) and HasItem(Config.Items.CardReader) and distance < Config.ATM.MinDistance
                    end,
                    onSelect = function(data)
                        InjectCard()
                    end
                }
            }
        })
    end
end)

-- Dynamic NPC targeting system
CreateThread(function()
    Wait(5000) -- Wait for ox_target to be ready
    while true do
        Wait(1000) -- Check every second
        
        if exports.ox_target then
            local playerPed = PlayerPedId()
            local playerCoords = GetEntityCoords(playerPed)
            local nearbyNPCs = {}
            
            -- Find nearby NPCs (peds that are not players)
            for ped in EnumeratePeds() do
                if ped ~= playerPed and DoesEntityExist(ped) and not IsPedAPlayer(ped) then
                    local pedCoords = GetEntityCoords(ped)
                    local distance = #(playerCoords - pedCoords)
                    
                    if distance < 10.0 then -- Within 10 meters
                        table.insert(nearbyNPCs, {ped = ped, coords = pedCoords, distance = distance})
                    end
                end
            end
            
            -- Add target to nearby NPCs that don't have it yet and haven't been skimmed
            for _, npcData in ipairs(nearbyNPCs) do
                local ped = npcData.ped
                if DoesEntityExist(ped) and not IsPedAPlayer(ped) and not skimmedNPCs[ped] then
                    -- Only add target option if NPC hasn't been skimmed
                    pcall(function()
                        exports.ox_target:addLocalEntity(ped, {
                            {
                                name = 'ccskim:skim:npc:' .. ped,
                                icon = 'fas fa-credit-card',
                                label = 'Skim Credit Card',
                                canInteract = function(entity, distance, coords, name, bone)
                                    print('[CCSkim] ===== DYNAMIC NPC canInteract CALLED =====')
                                    print(string.format('[CCSkim] Entity: %s, Distance: %.2f', tostring(entity), distance))
                                    
                                    -- Check if this NPC has already been skimmed
                                    if skimmedNPCs[entity] then
                                        print('[CCSkim] This NPC has already been skimmed!')
                                        return false
                                    end
                                    
                                    local hasSkimmer = HasItem(Config.Items.Skimmer)
                                    local onCooldown = GetGameTimer() - lastSkimTime < Config.Skimming.Cooldown
                                    
                                    print(string.format('[CCSkim] hasSkimmer: %s, distance: %.2f, isSkimming: %s, onCooldown: %s', 
                                        tostring(hasSkimmer), distance, tostring(isSkimming), tostring(onCooldown)))
                                    
                                    if not hasSkimmer then 
                                        print('[CCSkim] Missing card_skimmer!')
                                        return false 
                                    end
                                    if distance >= Config.Skimming.MinDistance then 
                                        print(string.format('[CCSkim] Too far! Distance: %.2f', distance))
                                        return false 
                                    end
                                    if isSkimming then return false end
                                    if onCooldown then return false end
                                    
                                    print('[CCSkim] All checks passed!')
                                    return true
                                end,
                                onSelect = function(data)
                                    print('[CCSkim] Dynamic NPC Skim selected!')
                                    print(string.format('[CCSkim] Selected entity: %s', tostring(data.entity)))
                                    -- Pass the entity to SkimCard
                                    SkimCard(data.entity)
                                end
                            }
                        })
                    end)
                end
            end
        end
    end
end)

-- Helper function to enumerate peds
function EnumeratePeds()
    return coroutine.wrap(function()
        local handle, ped = FindFirstPed()
        if not handle or handle == -1 then return end
        local success
        repeat
            coroutine.yield(ped)
            success, ped = FindNextPed(handle)
        until not success
        EndFindPed(handle)
    end)
end

-- Debug Commands (remove in production)
if Config.Debug then
    RegisterCommand('ccskim_debug', function()
        print('^2[CCSkim Debug]^7')
        print('Has Skimmer: ' .. tostring(HasItem(Config.Items.Skimmer)))
        print('Has Credit Card: ' .. tostring(HasItem(Config.Items.CreditCard)))
        print('Has Card Reader: ' .. tostring(HasItem(Config.Items.CardReader)))
        local atm = FindNearbyATM()
        print('Nearby ATM: ' .. tostring(atm ~= nil))
    end, false)
end

