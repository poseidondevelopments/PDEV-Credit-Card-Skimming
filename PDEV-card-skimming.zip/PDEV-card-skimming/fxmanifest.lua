-- ============================================
-- POSEIDON DEVELOPMENT - Credit Card Skimming
-- Copyright (c) 2025 Poseidon Developments - All Rights Reserved
-- ============================================

fx_version 'cerulean'
game 'gta5'

author 'Poseidon Developments'
description 'POSEIDON CARD SKIM - Credit Card Skimming Script with Shop System'
version '1.0.0'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua'
}

client_scripts {
    'client/main.lua',
    'client/shop.lua'
}

server_scripts {
    'server/framework.lua',
    'server/security.lua',
    'server/cache.lua',
    'server/banking.lua',
    'server/limits.lua',
    'server/shop.lua',
    'server/main.lua'
}

lua54 'yes'

